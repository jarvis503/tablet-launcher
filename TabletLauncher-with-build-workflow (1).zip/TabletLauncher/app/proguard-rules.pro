# ProGuard and R8 rules for TabletLauncher

# ---------------------------------------------------------
# Kotlin & Coroutines
# ---------------------------------------------------------
-keepattributes *Annotation*, InnerClasses, EnclosingMethod, Signature
-keepclassmembers,allowobfuscation class * {
    @kotlinx.coroutines.InternalCoroutinesApi <methods>;
}
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-dontwarn kotlinx.coroutines.**

# ---------------------------------------------------------
# Jetpack Compose Rules
# ---------------------------------------------------------
-keep class androidx.compose.runtime.** { *; }
-keep class androidx.compose.ui.** { *; }
-keep class androidx.compose.foundation.** { *; }
-keep class androidx.compose.material3.** { *; }
-keep class androidx.compose.animation.** { *; }

# Preserve Compose @Composable functions and Composer parameter
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}

# Preserve LiveData, StateFlow, and ViewModel reflection
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}
-keep class androidx.lifecycle.ViewModelProvider$Factory { *; }

# ---------------------------------------------------------
# Application Data Models & Repositories
# ---------------------------------------------------------
-keep class com.tabletlauncher.data.model.** { *; }
-keepclassmembers class com.tabletlauncher.data.model.** { *; }

-keep class com.tabletlauncher.data.repository.** { *; }
-keepclassmembers class com.tabletlauncher.data.repository.** { *; }

-keep class com.tabletlauncher.ui.viewmodel.** { *; }
-keepclassmembers class com.tabletlauncher.ui.viewmodel.** { *; }

# ---------------------------------------------------------
# Google Fonts & Downloadable Fonts
# ---------------------------------------------------------
-keep class androidx.compose.ui.text.google.fonts.** { *; }
-keep class androidx.core.provider.FontRequest { *; }
-keep class androidx.core.provider.FontsContractCompat { *; }

# ---------------------------------------------------------
# Android System & Coil Image Loading
# ---------------------------------------------------------
-dontwarn android.graphics.RenderEffect
-keep class coil.** { *; }
-dontwarn coil.**
