package com.tabletlauncher.data.repository

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.tabletlauncher.data.model.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.absoluteValue

/**
 * Repository responsible for loading, creating placeholders, and caching installed launchable applications.
 */
class AppRepository(
    private val context: Context
) {
    private val packageManager: PackageManager = context.packageManager
    private val mutex = Mutex()
    private var cachedApps: List<AppInfo>? = null

    /**
     * Retrieves all installed launchable apps, using the memory cache unless [forceRefresh] is true.
     * Guaranteed to execute on [Dispatchers.IO].
     */
    suspend fun getInstalledApps(forceRefresh: Boolean = false): List<AppInfo> = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!forceRefresh && cachedApps != null) {
                return@withContext cachedApps!!
            }

            val apps = queryInstalledApps()
            val resolvedApps = if (apps.isEmpty()) {
                generateFallbackMockApps()
            } else {
                apps
            }
            cachedApps = resolvedApps
            resolvedApps
        }
    }

    /**
     * Forces a fresh query of installed apps from the system [PackageManager].
     */
    suspend fun refresh(): List<AppInfo> = getInstalledApps(forceRefresh = true)

    /**
     * Queries launchable applications from [PackageManager] with security handling.
     */
    private fun queryInstalledApps(): List<AppInfo> {
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos: List<ResolveInfo> = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.queryIntentActivities(
                    launcherIntent,
                    PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
            }
        } catch (e: SecurityException) {
            // Permission denial for QUERY_ALL_PACKAGES on restricted platforms
            try {
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(launcherIntent, 0)
            } catch (e2: Exception) {
                emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }

        val currentPackageName = context.packageName

        return resolveInfos
            .filter { resolveInfo ->
                resolveInfo.activityInfo?.packageName != null &&
                resolveInfo.activityInfo.packageName != currentPackageName
            }
            .mapNotNull { resolveInfo ->
                try {
                    val packageName = resolveInfo.activityInfo.packageName
                    val rawLabel = resolveInfo.loadLabel(packageManager)?.toString()?.trim()
                    val label = if (!rawLabel.isNullOrBlank()) rawLabel else packageName

                    val drawable: Drawable? = try {
                        resolveInfo.loadIcon(packageManager)
                    } catch (e: Exception) {
                        null
                    }

                    val iconBitmap = if (drawable != null) {
                        try {
                            drawableToImageBitmap(drawable)
                        } catch (e: Exception) {
                            createPlaceholderIcon(label, packageName)
                        }
                    } else {
                        createPlaceholderIcon(label, packageName)
                    }

                    val appFlags = resolveInfo.activityInfo.applicationInfo?.flags ?: 0
                    val isSystemApp = (appFlags and ApplicationInfo.FLAG_SYSTEM) != 0

                    AppInfo(
                        packageName = packageName,
                        label = label,
                        icon = iconBitmap,
                        isSystemApp = isSystemApp
                    )
                } catch (e: Exception) {
                    null
                }
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    /**
     * Converts any Android [Drawable] (AdaptiveIconDrawable, VectorDrawable, BitmapDrawable)
     * into a Compose [ImageBitmap].
     */
    private fun drawableToImageBitmap(drawable: Drawable): ImageBitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap.asImageBitmap()
        }

        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 108
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 108

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap.asImageBitmap()
    }

    /**
     * Generates a crisp iPadOS squircle icon with vibrant gradient and bold initial
     * letter for applications that do not provide an icon or fail to load.
     */
    fun createPlaceholderIcon(label: String, packageName: String = ""): ImageBitmap {
        val size = 128
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Palette of vibrant iOS gradient color pairs
        val colorPairs = listOf(
            Pair(0xFF007AFF.toInt(), 0xFF5856D6.toInt()), // Blue to Indigo
            Pair(0xFF34C759.toInt(), 0xFF30B0C7.toInt()), // Green to Teal
            Pair(0xFFFF9500.toInt(), 0xFFFF2D55.toInt()), // Orange to Pink
            Pair(0xFF5856D6.toInt(), 0xFFAF52DE.toInt()), // Indigo to Purple
            Pair(0xFFFF2D55.toInt(), 0xFFFF3B30.toInt()), // Pink to Red
            Pair(0xFF00C7BE.toInt(), 0xFF007AFF.toInt()), // Teal to Blue
            Pair(0xFFFFCC00.toInt(), 0xFFFF9500.toInt())  // Yellow to Orange
        )

        val hash = (packageName.ifBlank { label }).hashCode()
        val pairIndex = (hash.absoluteValue % colorPairs.size)
        val (startColor, endColor) = colorPairs[pairIndex]

        // Rounded squircle background
        val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, size.toFloat(), size.toFloat(),
                startColor, endColor,
                Shader.TileMode.CLAMP
            )
        }
        val rect = RectF(0f, 0f, size.toFloat(), size.toFloat())
        val cornerRadius = size * 0.22f // 22% corner radius matching iPadOS
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, backgroundPaint)

        // Bold white initial letter
        val initial = label.trim().take(1).uppercase(Locale.getDefault()).ifBlank { "A" }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = size * 0.44f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val textY = (size / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
        canvas.drawText(initial, size / 2f, textY, textPaint)

        return bitmap.asImageBitmap()
    }

    /**
     * Fallback mock applications provided when running in sandboxed emulators or test environments
     * where zero launchable activities are queryable from the system.
     */
    private fun generateFallbackMockApps(): List<AppInfo> {
        val mockData = listOf(
            Pair("Safari", "com.apple.mobilesafari"),
            Pair("Mail", "com.apple.mobilemail"),
            Pair("Photos", "com.apple.mobileslideshow"),
            Pair("Camera", "com.apple.camera"),
            Pair("Calendar", "com.apple.mobilecal"),
            Pair("Clock", "com.apple.mobiletimer"),
            Pair("Maps", "com.apple.Maps"),
            Pair("Weather", "com.apple.weather"),
            Pair("Reminders", "com.apple.reminders"),
            Pair("Notes", "com.apple.mobilenotes"),
            Pair("Music", "com.apple.Music"),
            Pair("Podcasts", "com.apple.podcasts"),
            Pair("App Store", "com.apple.AppStore"),
            Pair("Settings", "com.apple.Preferences"),
            Pair("Files", "com.apple.DocumentsApp"),
            Pair("Calculator", "com.apple.calculator"),
            Pair("Books", "com.apple.iBooks"),
            Pair("News", "com.apple.news"),
            Pair("Health", "com.apple.Health"),
            Pair("Stocks", "com.apple.stocks")
        )

        return mockData.map { (label, pkg) ->
            AppInfo(
                packageName = pkg,
                label = label,
                icon = createPlaceholderIcon(label, pkg),
                isSystemApp = true
            )
        }
    }
}
