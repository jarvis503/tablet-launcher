package com.tabletlauncher.data.model

import java.util.UUID

/**
 * Represents an iPadOS-style app folder on the home screen.
 *
 * @property id Unique identifier for the folder, defaults to a generated UUID string.
 * @property name User-editable folder display title.
 * @property apps Mutable list of [AppInfo] applications contained within this folder.
 */
data class AppFolder(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val apps: MutableList<AppInfo> = mutableListOf()
)
