package com.tabletlauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.tabletlauncher.ui.theme.TabletLauncherTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enable edge-to-edge display: content draws behind system bars seamlessly
        enableEdgeToEdge()

        setContent {
            TabletLauncherTheme {
                LauncherApp()
            }
        }
    }
}
