package com.tabletlauncher.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.ui.animation.jiggle
import com.tabletlauncher.ui.layout.DeviceOrientation
import com.tabletlauncher.ui.layout.LocalDeviceOrientation
import com.tabletlauncher.ui.layout.LocalScreenDimensions
import com.tabletlauncher.ui.theme.IosShadowBlue
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * iPadOS-style floating dock supporting Jiggle Mode:
 * - Floating glassmorphism rounded bar.
 * - Icons jiggle in Jiggle Mode with out-of-sync phases.
 * - Top-left "X" delete badge on dock icons in Jiggle Mode.
 * - Drag-to-reorder dock icons in Jiggle Mode.
 * - Captures root bounds on launch tap for smooth iPadOS expansion animation.
 */
@Composable
fun IpadDock(
    dockApps: List<AppInfo>,
    suggestedApps: List<AppInfo> = emptyList(),
    onAppClick: (AppInfo, Rect?) -> Unit,
    modifier: Modifier = Modifier,
    isJiggleMode: Boolean = false,
    onAppLongClick: ((AppInfo) -> Unit)? = null,
    onRemoveDockApp: ((AppInfo) -> Unit)? = null,
    onReorderDockApps: ((fromIndex: Int, toIndex: Int) -> Unit)? = null
) {
    val orientation = LocalDeviceOrientation.current
    val screenDimensions = LocalScreenDimensions.current
    val configuration = LocalConfiguration.current

    val screenWidth = if (screenDimensions.width > 0.dp) screenDimensions.width else configuration.screenWidthDp.dp
    val maxDockWidth = screenWidth * 0.85f

    // Capacity & item spacing based on device orientation
    val maxApps = if (orientation == DeviceOrientation.Landscape) 15 else 8
    val itemSpacing = if (orientation == DeviceOrientation.Landscape) 12.dp else 14.dp

    // Pinned dock apps
    val visibleDockApps = dockApps.take(maxApps)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        FrostedGlassBox(
            modifier = Modifier
                .wrapContentWidth()
                .widthIn(max = maxDockWidth),
            shape = RoundedCornerShape(22.dp),
            backgroundColor = Color.White.copy(alpha = 0.15f),
            borderColor = Color.White.copy(alpha = 0.10f),
            borderWidth = 0.5.dp,
            elevation = 4.dp,
            shadowColor = IosShadowBlue
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(itemSpacing)
            ) {
                // Section 1: Pinned apps
                visibleDockApps.forEachIndexed { index, app ->
                    DockIconItem(
                        app = app,
                        index = index,
                        onClick = { a, bounds -> onAppClick(a, bounds) },
                        onLongClick = onAppLongClick?.let { { it(app) } },
                        isJiggleMode = isJiggleMode,
                        onDeleteClick = onRemoveDockApp?.let { { it(app) } },
                        onReorder = { targetIndex ->
                            onReorderDockApps?.invoke(index, targetIndex)
                        }
                    )
                }

                // Divider line (0.5dp, white 30% opacity)
                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .width(0.5.dp)
                        .height(34.dp)
                        .background(Color.White.copy(alpha = 0.30f))
                )

                // Section 2: Suggested / Recent Apps
                if (suggestedApps.isNotEmpty()) {
                    suggestedApps.take(3).forEachIndexed { index, app ->
                        DockIconItem(
                            app = app,
                            index = visibleDockApps.size + index,
                            onClick = { a, bounds -> onAppClick(a, bounds) },
                            onLongClick = onAppLongClick?.let { { it(app) } },
                            isJiggleMode = isJiggleMode,
                            onDeleteClick = null,
                            onReorder = null
                        )
                    }
                }
            }
        }
    }
}

/**
 * Individual 50dp dock app icon with iPadOS-style press bounce feedback, bounds capture,
 * jiggle animation, and drag-to-reorder support.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DockIconItem(
    app: AppInfo,
    index: Int,
    onClick: (AppInfo, Rect) -> Unit,
    onLongClick: (() -> Unit)?,
    isJiggleMode: Boolean,
    onDeleteClick: (() -> Unit)?,
    onReorder: ((Int) -> Unit)?
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    var dragOffsetX by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }
    var iconBounds by remember { mutableStateOf(Rect.Zero) }

    // 1. Entry bounce animation: scale in from 0 to 1 with a spring bounce when added
    val entryScale = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        entryScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = 0.5f,
                stiffness = Spring.StiffnessMediumLow
            )
        )
    }

    // 2. Exit animation: scale down and fade out when removed
    var isExiting by remember { mutableStateOf(false) }
    val exitScale by animateFloatAsState(
        targetValue = if (isExiting) 0f else 1f,
        animationSpec = tween(durationMillis = 200),
        label = "dock_exit_scale"
    )
    val exitAlpha by animateFloatAsState(
        targetValue = if (isExiting) 0f else 1f,
        animationSpec = tween(durationMillis = 200),
        label = "dock_exit_alpha"
    )

    LaunchedEffect(isExiting) {
        if (isExiting) {
            delay(200)
            onDeleteClick?.invoke()
        }
    }

    // 3. Press animation: scale to 0.85 with spring(dampingRatio = 0.4) for a slight bounce
    val pressScale by animateFloatAsState(
        targetValue = if (isDragging) 1.10f else if (isPressed) 0.85f else 1f,
        animationSpec = spring(
            dampingRatio = 0.4f,
            stiffness = Spring.StiffnessMedium
        ),
        label = "dock_icon_press"
    )

    // Subtle brightness reduction on the icon when pressed (darken overlay)
    val darkenAlpha by animateFloatAsState(
        targetValue = if (isPressed) 0.22f else 0.0f,
        animationSpec = tween(durationMillis = 100),
        label = "dock_icon_darken"
    )

    val totalScale = entryScale.value * pressScale * exitScale
    val totalAlpha = exitAlpha

    Box(
        modifier = Modifier
            .size(50.dp)
            .zIndex(if (isDragging) 10f else 1f)
            .offset { IntOffset(dragOffsetX.roundToInt(), 0) }
            .jiggle(isJiggleMode = isJiggleMode && !isDragging, seed = index)
            .onGloballyPositioned { coordinates ->
                iconBounds = coordinates.boundsInRoot()
            }
            .pointerInput(isJiggleMode) {
                if (!isJiggleMode) return@pointerInput
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        isDragging = true
                        dragOffsetX = 0f
                    },
                    onDragEnd = {
                        isDragging = false
                        val slotShift = (dragOffsetX / 62.dp.toPx()).roundToInt()
                        if (slotShift != 0 && onReorder != null) {
                            val targetIndex = (index + slotShift).coerceAtLeast(0)
                            onReorder(targetIndex)
                        }
                        dragOffsetX = 0f
                    },
                    onDragCancel = {
                        isDragging = false
                        dragOffsetX = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragOffsetX += dragAmount.x
                    }
                )
            }
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    onClick(app, iconBounds)
                },
                onLongClick = onLongClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .graphicsLayer {
                    scaleX = totalScale
                    scaleY = totalScale
                    alpha = totalAlpha
                }
                .clip(RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Subtle darken overlay on press
            if (darkenAlpha > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = darkenAlpha))
                )
            }
        }

        // Top-Left "X" Badge in Jiggle Mode (18dp circle)
        if (isJiggleMode && onDeleteClick != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (-4).dp, y = (-4).dp)
                    .size(18.dp)
                    .shadow(3.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color(0xFF48484A))
                    .border(
                        BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
                        CircleShape
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        isExiting = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Remove App from Dock",
                    tint = Color.White,
                    modifier = Modifier.size(11.dp)
                )
            }
        }
    }
}
