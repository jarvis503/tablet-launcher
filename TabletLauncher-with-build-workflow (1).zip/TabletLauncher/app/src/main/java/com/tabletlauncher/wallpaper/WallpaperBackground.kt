package com.tabletlauncher.wallpaper

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.max

// Default iPadOS dark wallpaper color palette
private val DeepBlueTop = Color(0xFF1A1A2E)
private val DarkPurpleBottom = Color(0xFF16213E)
private val LighterBlueCenter = Color(0xFF0F3460)

// iPadOS light mode wallpaper color palette
private val LightBlueTop = Color(0xFF60A5FA)
private val LightPurpleBottom = Color(0xFF818CF8)
private val LightWarmCenter = Color(0xFFFDE047)

/**
 * Fullscreen composable that draws the wallpaper layer at the bottom of [LauncherScaffold].
 *
 * - Renders custom [android.graphics.Bitmap] when provided in [WallpaperManager].
 * - When no custom bitmap is set, draws the default iPadOS gradient:
 *   top #1A1A2E -> bottom #16213E with a subtle radial glow of #0F3460 in the center.
 * - Applies a subtle parallax translation animated across home screen page navigation.
 */
@Composable
fun WallpaperBackground(
    modifier: Modifier = Modifier
) {
    val wallpaperState = WallpaperManager.currentWallpaper
    val targetOffset = WallpaperManager.parallaxOffset

    // Animate parallax offset with smooth physics
    val animatedOffset by animateFloatAsState(
        targetValue = targetOffset,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "wallpaper_parallax"
    )

    // Subtle max horizontal shift (36dp)
    val maxShiftPx = with(LocalDensity.current) { 36.dp.toPx() }
    val translationX = animatedOffset * maxShiftPx

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                // Subtle scale to prevent borders from revealing during parallax translation
                scaleX = 1.08f
                scaleY = 1.08f
                this.translationX = translationX
            }
    ) {
        when (val state = wallpaperState) {
            is WallpaperState.Custom -> {
                Image(
                    bitmap = state.bitmap.asImageBitmap(),
                    contentDescription = "Custom Wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            is WallpaperState.Default -> {
                DefaultGradientWallpaper(
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Subtle vignette effect overlay on the wallpaper (edges slightly darker to add depth)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerOffset = Offset(size.width * 0.5f, size.height * 0.5f)
            val maxDim = max(size.width, size.height)
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.Transparent,
                        Color(0xFF020617).copy(alpha = 0.38f)
                    ),
                    center = centerOffset,
                    radius = maxDim * 0.75f
                )
            )
        }
    }
}

/**
 * Draws the smooth iPadOS dark gradient wallpaper aesthetic.
 */
@Composable
private fun DefaultGradientWallpaper(
    modifier: Modifier = Modifier
) {
    val isDark = WallpaperManager.isDarkMode

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        val topColor = if (isDark) DeepBlueTop else LightBlueTop
        val bottomColor = if (isDark) DarkPurpleBottom else LightPurpleBottom
        val centerGlowColor = if (isDark) LighterBlueCenter else LightWarmCenter

        // 1. Base vertical linear gradient
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    topColor,
                    bottomColor
                ),
                startY = 0f,
                endY = height
            )
        )

        // 2. Subtle radial gradient in the center
        val centerOffset = Offset(width * 0.5f, height * 0.45f)
        val glowRadius = max(width, height) * 0.65f

        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    centerGlowColor.copy(alpha = if (isDark) 0.75f else 0.55f),
                    centerGlowColor.copy(alpha = if (isDark) 0.35f else 0.20f),
                    Color.Transparent
                ),
                center = centerOffset,
                radius = glowRadius
            )
        )
    }
}
