package com.tabletlauncher.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.theme.IosBlue
import com.tabletlauncher.ui.theme.IosRed
import com.tabletlauncher.ui.theme.IosShadowBlue
import com.tabletlauncher.ui.theme.IosSurfaceDark
import com.tabletlauncher.ui.theme.TextSecondary

private val DialogShape = RoundedCornerShape(14.dp)

/**
 * iPadOS-style confirmation dialog shown when tapping the "X" delete button in Jiggle Mode.
 */
@Composable
fun RemoveAppDialog(
    app: AppInfo?,
    onConfirm: (AppInfo) -> Unit,
    onDismiss: () -> Unit
) {
    if (app == null) return

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .width(320.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = DialogShape,
                    ambientColor = IosShadowBlue.copy(alpha = 0.35f),
                    spotColor = IosShadowBlue.copy(alpha = 0.50f)
                )
                .clip(DialogShape)
                .background(IosSurfaceDark.copy(alpha = 0.92f))
                .border(BorderStroke(0.5.dp, FrostedGlassBorder), DialogShape)
                .padding(top = 22.dp, bottom = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Title: weight 600 SemiBold
                Text(
                    text = "Remove from Home Screen?",
                    fontFamily = InterFontFamily,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Subtitle explanation in secondary text (white 60%)
                Text(
                    text = "Removing \"${app.label}\" from the Home Screen keeps the app available in your App Library.",
                    fontFamily = InterFontFamily,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Divider (0.5dp)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(0.5.dp)
                        .background(FrostedGlassBorder)
                )

                // Destructive "Remove from Home Screen" action button: iOS red (#FF3B30)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onConfirm(app)
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Remove from Home Screen",
                        fontFamily = InterFontFamily,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = IosRed, // iOS red (#FF3B30)
                        textAlign = TextAlign.Center
                    )
                }

                // Divider (0.5dp)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(0.5.dp)
                        .background(FrostedGlassBorder)
                )

                // Cancel button: iOS blue (#007AFF)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onDismiss()
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Cancel",
                        fontFamily = InterFontFamily,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = IosBlue, // iOS blue (#007AFF)
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
