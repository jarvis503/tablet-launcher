package com.tabletlauncher.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.tabletlauncher.data.model.HomeScreenItem
import org.json.JSONArray
import org.json.JSONObject

/**
 * Representation of a saved home screen item for serialization/deserialization.
 */
sealed class SavedPageItem {
    data class App(val packageName: String) : SavedPageItem()
    data class Folder(val id: String, val name: String, val packageNames: List<String>) : SavedPageItem()
    data class Widget(val id: String, val widgetType: String, val size: String, val title: String) : SavedPageItem()
}

/**
 * Representation of saved Control Center and system settings.
 */
data class SavedSettings(
    val isDarkMode: Boolean = true,
    val isAirplaneMode: Boolean = false,
    val isWifiEnabled: Boolean = true,
    val isBluetoothEnabled: Boolean = true,
    val isAirDropEnabled: Boolean = true,
    val isRotationLocked: Boolean = false,
    val isDoNotDisturb: Boolean = false,
    val brightness: Float = 0.80f,
    val volume: Float = 0.65f
)

/**
 * Local persistent store using [SharedPreferences] for:
 * 1. Pinned dock applications.
 * 2. Home screen page layouts (App items, Folders with custom names, and Widgets).
 * 3. User settings (Dark mode, toggles, brightness, volume).
 */
class LauncherPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Persists the ordered list of dock app package names.
     */
    fun saveDockApps(packageNames: List<String>) {
        try {
            val jsonArray = JSONArray()
            packageNames.forEach { jsonArray.put(it) }
            prefs.edit().putString(KEY_DOCK_APPS, jsonArray.toString()).apply()
        } catch (e: Exception) {
            // Gracefully ignore serialization errors
        }
    }

    /**
     * Retrieves the saved dock app package names. Returns null if never saved.
     */
    fun getDockApps(): List<String>? {
        val rawJson = prefs.getString(KEY_DOCK_APPS, null) ?: return null
        return try {
            val jsonArray = JSONArray(rawJson)
            val list = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) {
                val pkg = jsonArray.optString(i)
                if (!pkg.isNullOrBlank()) {
                    list.add(pkg)
                }
            }
            list
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Persists the full home screen page structure across all pages.
     */
    fun saveHomeScreenPages(pages: Map<Int, List<HomeScreenItem>>) {
        try {
            val root = JSONObject()
            for ((pageIdx, items) in pages) {
                val pageArray = JSONArray()
                for (item in items) {
                    val itemObj = JSONObject()
                    when (item) {
                        is HomeScreenItem.AppItem -> {
                            itemObj.put("type", "app")
                            itemObj.put("pkg", item.app.packageName)
                        }
                        is HomeScreenItem.FolderItem -> {
                            itemObj.put("type", "folder")
                            itemObj.put("id", item.folder.id)
                            itemObj.put("name", item.folder.name)
                            val appArray = JSONArray()
                            item.folder.apps.forEach { appArray.put(it.packageName) }
                            itemObj.put("apps", appArray)
                        }
                        is HomeScreenItem.WidgetItem -> {
                            itemObj.put("type", "widget")
                            itemObj.put("id", item.widget.id)
                            itemObj.put("widgetType", item.widget.type.name)
                            itemObj.put("size", item.widget.size.name)
                            itemObj.put("title", item.widget.title)
                        }
                    }
                    pageArray.put(itemObj)
                }
                root.put(pageIdx.toString(), pageArray)
            }
            prefs.edit().putString(KEY_HOME_PAGES, root.toString()).apply()
        } catch (e: Exception) {
            // Gracefully ignore serialization errors
        }
    }

    /**
     * Loads the saved home screen structure. Returns null if never saved.
     */
    fun getHomeScreenPages(): Map<Int, List<SavedPageItem>>? {
        val rawJson = prefs.getString(KEY_HOME_PAGES, null) ?: return null
        return try {
            val root = JSONObject(rawJson)
            val result = mutableMapOf<Int, List<SavedPageItem>>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val pageKey = keys.next()
                val pageIdx = pageKey.toIntOrNull() ?: continue
                val pageArray = root.getJSONArray(pageKey)
                val itemsList = mutableListOf<SavedPageItem>()
                for (i in 0 until pageArray.length()) {
                    val obj = pageArray.getJSONObject(i)
                    when (obj.optString("type")) {
                        "app" -> {
                            val pkg = obj.optString("pkg")
                            if (pkg.isNotBlank()) {
                                itemsList.add(SavedPageItem.App(pkg))
                            }
                        }
                        "folder" -> {
                            val id = obj.optString("id")
                            val name = obj.optString("name", "Folder")
                            val appsArr = obj.optJSONArray("apps") ?: JSONArray()
                            val pkgs = mutableListOf<String>()
                            for (j in 0 until appsArr.length()) {
                                val p = appsArr.optString(j)
                                if (p.isNotBlank()) pkgs.add(p)
                            }
                            itemsList.add(SavedPageItem.Folder(id, name, pkgs))
                        }
                        "widget" -> {
                            val id = obj.optString("id")
                            val widgetType = obj.optString("widgetType", "Weather")
                            val size = obj.optString("size", "Medium")
                            val title = obj.optString("title", widgetType)
                            itemsList.add(SavedPageItem.Widget(id, widgetType, size, title))
                        }
                    }
                }
                result[pageIdx] = itemsList
            }
            if (result.isEmpty()) null else result
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Persists settings changes.
     */
    fun saveSettings(settings: SavedSettings) {
        prefs.edit()
            .putBoolean(KEY_DARK_MODE, settings.isDarkMode)
            .putBoolean(KEY_AIRPLANE_MODE, settings.isAirplaneMode)
            .putBoolean(KEY_WIFI_ENABLED, settings.isWifiEnabled)
            .putBoolean(KEY_BLUETOOTH_ENABLED, settings.isBluetoothEnabled)
            .putBoolean(KEY_AIRDROP_ENABLED, settings.isAirDropEnabled)
            .putBoolean(KEY_ROTATION_LOCKED, settings.isRotationLocked)
            .putBoolean(KEY_DND_ENABLED, settings.isDoNotDisturb)
            .putFloat(KEY_BRIGHTNESS, settings.brightness)
            .putFloat(KEY_VOLUME, settings.volume)
            .apply()
    }

    /**
     * Loads saved settings.
     */
    fun getSettings(): SavedSettings {
        return SavedSettings(
            isDarkMode = prefs.getBoolean(KEY_DARK_MODE, true),
            isAirplaneMode = prefs.getBoolean(KEY_AIRPLANE_MODE, false),
            isWifiEnabled = prefs.getBoolean(KEY_WIFI_ENABLED, true),
            isBluetoothEnabled = prefs.getBoolean(KEY_BLUETOOTH_ENABLED, true),
            isAirDropEnabled = prefs.getBoolean(KEY_AIRDROP_ENABLED, true),
            isRotationLocked = prefs.getBoolean(KEY_ROTATION_LOCKED, false),
            isDoNotDisturb = prefs.getBoolean(KEY_DND_ENABLED, false),
            brightness = prefs.getFloat(KEY_BRIGHTNESS, 0.80f),
            volume = prefs.getFloat(KEY_VOLUME, 0.65f)
        )
    }

    companion object {
        private const val PREFS_NAME = "tablet_launcher_prefs"
        private const val KEY_DOCK_APPS = "key_dock_apps"
        private const val KEY_HOME_PAGES = "key_home_pages"
        private const val KEY_DARK_MODE = "key_dark_mode"
        private const val KEY_AIRPLANE_MODE = "key_airplane_mode"
        private const val KEY_WIFI_ENABLED = "key_wifi_enabled"
        private const val KEY_BLUETOOTH_ENABLED = "key_bluetooth_enabled"
        private const val KEY_AIRDROP_ENABLED = "key_airdrop_enabled"
        private const val KEY_ROTATION_LOCKED = "key_rotation_locked"
        private const val KEY_DND_ENABLED = "key_dnd_enabled"
        private const val KEY_BRIGHTNESS = "key_brightness"
        private const val KEY_VOLUME = "key_volume"
    }
}
