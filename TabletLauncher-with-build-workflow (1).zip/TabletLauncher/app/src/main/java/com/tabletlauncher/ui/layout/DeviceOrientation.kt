package com.tabletlauncher.ui.layout

import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.platform.LocalConfiguration

/**
 * Orientation states of the device.
 */
enum class DeviceOrientation {
    Portrait,
    Landscape;

    val isPortrait: Boolean get() = this == Portrait
    val isLandscape: Boolean get() = this == Landscape
}

/**
 * Composable that provides the current [DeviceOrientation] using [LocalConfiguration].
 */
@Composable
fun rememberDeviceOrientation(): DeviceOrientation {
    val configuration = LocalConfiguration.current
    return if (configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
        DeviceOrientation.Landscape
    } else {
        DeviceOrientation.Portrait
    }
}

/**
 * CompositionLocal providing the current [DeviceOrientation].
 */
val LocalDeviceOrientation = compositionLocalOf { DeviceOrientation.Portrait }
