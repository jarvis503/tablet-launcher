package com.tabletlauncher.ui.components

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.ui.animation.jiggle
import com.tabletlauncher.ui.theme.InterFontFamily

// iPadOS-style squircle / rounded square shape: 22% of icon size (13.2dp for 60dp icon)
private val IconRoundedShape = RoundedCornerShape(13.2.dp)

// Soft text shadow for clear legibility over any wallpaper
private val LabelTextShadow = Shadow(
    color = Color.Black.copy(alpha = 0.6f),
    offset = Offset(0f, 1.5f),
    blurRadius = 3f
)

private val IconLabelStyle = TextStyle(
    fontFamily = InterFontFamily,
    fontSize = 11.sp,
    fontWeight = FontWeight.Normal, // Weight 400 (Regular)
    color = Color.White,
    shadow = LabelTextShadow
)

/**
 * Reusable iPadOS-style app icon composable.
 *
 * Characteristics:
 * 1. Rendered as a rounded square with 14dp corner radius.
 * 2. Icon size: 60dp, completely filled using [ContentScale.Crop].
 * 3. Centered app label in white text, 11sp, medium weight.
 * 4. Label limited to max 1 line with ellipsis overflow.
 * 5. 4dp vertical spacing between icon and label.
 * 6. Fits smoothly within tablet grid cells.
 * 7. Tap: executes [onClickWithBounds] capturing root bounds for smooth launch animation.
 * 8. Long press: triggers [onLongClick] to activate Jiggle Mode.
 * 9. Jiggle Mode: continuous subtle rotation (-2° to +2°) with varied timing.
 * 10. Delete Button: 18dp gray circle with white "X" on top-left corner in Jiggle Mode.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIconItem(
    app: AppInfo,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onClickWithBounds: ((AppInfo, Rect) -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    isJiggleMode: Boolean = false,
    seed: Int = 0,
    onDeleteClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    var iconBounds by remember { mutableStateOf(Rect.Zero) }

    // Enhanced press scale animation: scale to 0.85 with a spring(dampingRatio = 0.4) for a slight bounce
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.85f else 1.0f,
        animationSpec = spring(
            dampingRatio = 0.4f,
            stiffness = Spring.StiffnessMedium
        ),
        label = "app_icon_press_scale"
    )

    // Subtle brightness reduction on the icon when pressed (darken overlay)
    val darkenAlpha by animateFloatAsState(
        targetValue = if (isPressed) 0.22f else 0.0f,
        animationSpec = tween(durationMillis = 100),
        label = "app_icon_darken"
    )

    Column(
        modifier = modifier
            .widthIn(min = 60.dp, max = 80.dp)
            .jiggle(isJiggleMode = isJiggleMode, seed = seed)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    if (onClickWithBounds != null && !iconBounds.isEmpty) {
                        onClickWithBounds(app, iconBounds)
                    } else {
                        onClick()
                    }
                },
                onLongClick = {
                    if (onLongClick != null) {
                        onLongClick()
                    } else {
                        Toast.makeText(context, "Long pressed: ${app.label}", Toast.LENGTH_SHORT).show()
                    }
                }
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Icon container with top-left "X" delete badge
        Box(
            modifier = Modifier.size(60.dp),
            contentAlignment = Alignment.Center
        ) {
            // 60dp Icon container with scale animation, root bounds capture, and rounded square clipping
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
                    .onGloballyPositioned { coordinates ->
                        iconBounds = coordinates.boundsInRoot()
                    }
                    .clip(IconRoundedShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Subtle darken overlay on press
                if (darkenAlpha > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = darkenAlpha))
                    )
                }
            }

            // Top-Left "X" Delete Badge in Jiggle Mode (18dp gray circle with white "X")
            if (isJiggleMode && onDeleteClick != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = (-4).dp, y = (-4).dp)
                        .size(18.dp)
                        .shadow(3.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color(0xFF48484A))
                        .border(
                            BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
                            CircleShape
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onDeleteClick()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Remove App from Home Screen",
                        tint = Color.White,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // App Label: 11sp, medium weight, white, max 1 line with ellipsis
        Text(
            text = app.label,
            style = IconLabelStyle,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
