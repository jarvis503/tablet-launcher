package com.tabletlauncher.ui.layout

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Grid sizing and layout dimensions for TabletLauncher.
 */
object LauncherDimens {
    // Grid sizing
    const val PORTRAIT_COLUMNS = 5
    const val PORTRAIT_ROWS = 6

    const val LANDSCAPE_COLUMNS = 7
    const val LANDSCAPE_ROWS = 4

    // App Icon & Label dimensions
    val IconSize: Dp = 60.dp
    val IconLabelSize: TextUnit = 11.sp

    // Grid spacing & padding
    val GridHorizontalPadding: Dp = 24.dp
    val GridVerticalSpacing: Dp = 20.dp

    /**
     * Resolves the app icon column count for the given [orientation].
     */
    fun getColumns(orientation: DeviceOrientation): Int = when (orientation) {
        DeviceOrientation.Portrait -> PORTRAIT_COLUMNS
        DeviceOrientation.Landscape -> LANDSCAPE_COLUMNS
    }

    /**
     * Resolves the app icon row count for the given [orientation].
     */
    fun getRows(orientation: DeviceOrientation): Int = when (orientation) {
        DeviceOrientation.Portrait -> PORTRAIT_ROWS
        DeviceOrientation.Landscape -> LANDSCAPE_ROWS
    }

    /**
     * Calculates the maximum number of apps displayed per page.
     */
    fun getAppsPerPage(orientation: DeviceOrientation): Int =
        getColumns(orientation) * getRows(orientation)
}
