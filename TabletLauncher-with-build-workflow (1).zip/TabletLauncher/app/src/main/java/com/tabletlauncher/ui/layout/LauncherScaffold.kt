package com.tabletlauncher.ui.layout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.tabletlauncher.wallpaper.WallpaperBackground

/**
 * Screen dimensions in density-independent pixels.
 */
data class ScreenDimensions(
    val width: Dp = 0.dp,
    val height: Dp = 0.dp
)

/**
 * CompositionLocal providing current [ScreenDimensions] to child composables.
 */
val LocalScreenDimensions = compositionLocalOf {
    ScreenDimensions()
}

/**
 * Root responsive scaffold for TabletLauncher.
 *
 * Detects device orientation and window size classes, provides screen dimensions
 * via [LocalScreenDimensions], and arranges three key slots:
 * - [statusBar]: Top bar area with status bar window insets handled
 * - [content]: Center area that fills all remaining vertical space
 * - [dock]: Bottom dock area with navigation bar window insets handled
 */
@Composable
fun LauncherScaffold(
    modifier: Modifier = Modifier,
    containerColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Transparent,
    statusBar: @Composable () -> Unit = {},
    dock: @Composable () -> Unit = {},
    content: @Composable () -> Unit
) {
    val orientation = rememberDeviceOrientation()
    val windowSizeClass = rememberWindowSizeClass()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(containerColor)
    ) {
        val screenDimensions = ScreenDimensions(
            width = maxWidth,
            height = maxHeight
        )

        CompositionLocalProvider(
            LocalScreenDimensions provides screenDimensions,
            LocalDeviceOrientation provides orientation,
            LocalWindowSizeClass provides windowSizeClass
        ) {
            // Lowest layer: WallpaperBackground drawn behind all slots
            WallpaperBackground()

            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Slot: StatusBar (draws edge-to-edge; insets handled by statusBar content)
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    statusBar()
                }

                // Center Slot: Content (fills remaining space)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    content()
                }

                // Bottom Slot: Dock
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars),
                    contentAlignment = Alignment.Center
                ) {
                    dock()
                }
            }
        }
    }
}
