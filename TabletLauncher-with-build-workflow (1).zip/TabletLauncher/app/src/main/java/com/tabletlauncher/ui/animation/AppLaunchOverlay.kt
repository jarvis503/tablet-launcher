package com.tabletlauncher.ui.animation

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.zIndex
import com.tabletlauncher.data.model.AppInfo
import kotlin.math.roundToInt

// Smooth iPadOS EaseInOut curve (standard CSS / iOS timing)
val EaseInOut = CubicBezierEasing(0.42f, 0f, 0.58f, 1f)

/**
 * State representing an active app launch animation.
 *
 * @property app The application being launched.
 * @property sourceBounds Screen bounding rectangle of the tapped icon.
 */
data class AppLaunchState(
    val app: AppInfo,
    val sourceBounds: Rect
)

/**
 * Fullscreen iPadOS-style app launch overlay:
 * 1. The tapped icon bounds scale up smoothly from its position.
 * 2. Simultaneously, a bright white overlay rectangle expands from the icon's bounds to fill the full screen.
 * 3. Expansion curve is EaseInOut with a 400ms duration.
 * 4. The icon inside scales up and cross-fades into the solid white rectangle.
 */
@Composable
fun AppLaunchOverlay(
    launchState: AppLaunchState?,
    progress: Float,
    screenWidthPx: Float,
    screenHeightPx: Float,
    modifier: Modifier = Modifier
) {
    if (launchState == null || progress <= 0f) return

    val density = LocalDensity.current
    val bounds = launchState.sourceBounds

    // Interpolate bounds from icon bounds towards full screen bounds
    val currentLeft = lerp(bounds.left, 0f, progress)
    val currentTop = lerp(bounds.top, 0f, progress)
    val currentRight = lerp(bounds.right, screenWidthPx, progress)
    val currentBottom = lerp(bounds.bottom, screenHeightPx, progress)

    val currentWidthPx = (currentRight - currentLeft).coerceAtLeast(1f)
    val currentHeightPx = (currentBottom - currentTop).coerceAtLeast(1f)

    // Corner radius smoothly morphs from 14dp down to 0dp as it expands to full screen
    val initialRadiusPx = with(density) { 14.dp.toPx() }
    val currentRadiusPx = lerp(initialRadiusPx, 0f, progress)
    val currentShape = RoundedCornerShape(with(density) { currentRadiusPx.toDp() })

    // Icon scale and alpha: icon scales up from 1.0 to ~3.2 and cross-fades into the white screen
    val iconScale = lerp(1f, 3.2f, progress)
    val iconAlpha = (1f - progress * 1.5f).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .zIndex(100f)
    ) {
        // Expanding white / bright overlay rectangle
        Box(
            modifier = Modifier
                .offset { IntOffset(currentLeft.roundToInt(), currentTop.roundToInt()) }
                .size(
                    width = with(density) { currentWidthPx.toDp() },
                    height = with(density) { currentHeightPx.toDp() }
                )
                .shadow(
                    elevation = (24f * (1f - progress)).dp,
                    shape = currentShape,
                    clip = false
                )
                .clip(currentShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            // App icon scaling up and cross-fading into the white surface
            if (iconAlpha > 0f) {
                Image(
                    bitmap = launchState.app.icon,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(60.dp)
                        .graphicsLayer {
                            scaleX = iconScale
                            scaleY = iconScale
                            alpha = iconAlpha
                        }
                        .clip(RoundedCornerShape(14.dp))
                )
            }
        }
    }
}
