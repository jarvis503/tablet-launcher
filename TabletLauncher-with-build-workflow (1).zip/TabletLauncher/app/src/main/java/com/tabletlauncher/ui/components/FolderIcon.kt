package com.tabletlauncher.ui.components

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.data.model.AppFolder
import com.tabletlauncher.ui.animation.jiggle
import com.tabletlauncher.ui.theme.InterFontFamily

// iPadOS-style squircle / rounded square shape: 22% of icon size (13.2dp for 60dp icon)
private val FolderRoundedShape = RoundedCornerShape(13.2.dp)
private val MiniIconShape = RoundedCornerShape(3.dp)

// Soft text shadow for readability over wallpapers
private val FolderLabelTextShadow = Shadow(
    color = Color.Black.copy(alpha = 0.6f),
    offset = Offset(0f, 1.5f),
    blurRadius = 3f
)

private val FolderLabelStyle = TextStyle(
    fontFamily = InterFontFamily,
    fontSize = 11.sp,
    fontWeight = FontWeight.Normal, // Weight 400 (Regular)
    color = Color.White,
    shadow = FolderLabelTextShadow
)

/**
 * iPadOS-style folder composable on the home screen.
 *
 * Characteristics:
 * 1. 60dp rounded square container with 14dp corner radius.
 * 2. Frosted glass semi-transparent background with subtle white border.
 * 3. 3x3 mini-grid of the first 9 app icons (14dp each) from the folder.
 * 4. Folder name below in white 11sp medium text with subtle shadow.
 * 5. Scale-down press animation (scale to 0.9) with spring physics.
 * 6. Jiggle Mode: continuous subtle rotation (-2° to +2°) with varied timing.
 * 7. Top-Left "X" Delete Badge in Jiggle Mode.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderIcon(
    folder: AppFolder,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    isJiggleMode: Boolean = false,
    seed: Int = 0,
    onDeleteClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Enhanced press scale animation: scale to 0.85 with a spring(dampingRatio = 0.4) for a slight bounce
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.85f else 1.0f,
        animationSpec = spring(
            dampingRatio = 0.4f,
            stiffness = Spring.StiffnessMedium
        ),
        label = "folder_icon_press_scale"
    )

    // Subtle brightness reduction on the folder icon when pressed (darken overlay)
    val darkenAlpha by animateFloatAsState(
        targetValue = if (isPressed) 0.22f else 0.0f,
        animationSpec = tween(durationMillis = 100),
        label = "folder_darken"
    )

    Column(
        modifier = modifier
            .widthIn(min = 60.dp, max = 80.dp)
            .jiggle(isJiggleMode = isJiggleMode, seed = seed)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
                onLongClick = {
                    if (onLongClick != null) {
                        onLongClick()
                    } else {
                        Toast.makeText(context, "Folder: ${folder.name}", Toast.LENGTH_SHORT).show()
                    }
                }
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 60dp Frosted glass folder container with delete badge
        Box(
            modifier = Modifier.size(60.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
                    .clip(FolderRoundedShape)
                    .background(Color.White.copy(alpha = 0.15f))
                    .border(
                        BorderStroke(0.5.dp, Color.White.copy(alpha = 0.10f)),
                        FolderRoundedShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                // 3x3 Mini-grid of up to 9 app icons
                val previewApps = folder.apps.take(9)

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    repeat(3) { rowIndex ->
                        val startIndex = rowIndex * 3
                        if (startIndex < previewApps.size) {
                            val rowApps = previewApps.drop(startIndex).take(3)
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(3.dp, Alignment.Start),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                rowApps.forEach { app ->
                                    Image(
                                        bitmap = app.icon,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clip(MiniIconShape)
                                    )
                                }
                                repeat(3 - rowApps.size) {
                                    Spacer(modifier = Modifier.size(14.dp))
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.size(14.dp))
                        }
                    }
                }

                // Subtle darken overlay on press
                if (darkenAlpha > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = darkenAlpha))
                    )
                }
            }

            // Top-Left "X" Delete Badge in Jiggle Mode
            if (isJiggleMode && onDeleteClick != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = (-4).dp, y = (-4).dp)
                        .size(18.dp)
                        .shadow(3.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color(0xFF48484A))
                        .border(
                            BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
                            CircleShape
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onDeleteClick()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Remove Folder",
                        tint = Color.White,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Folder Name Label: 11sp, medium weight, white, max 1 line with ellipsis
        Text(
            text = folder.name,
            style = FolderLabelStyle,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
