package com.tabletlauncher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ScreenLockRotation
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.ui.layout.DeviceOrientation
import com.tabletlauncher.ui.layout.LocalDeviceOrientation
import com.tabletlauncher.ui.theme.FrostedGlassBackground
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.theme.IosBlue
import com.tabletlauncher.ui.theme.IosGreen
import com.tabletlauncher.ui.theme.IosRed
import com.tabletlauncher.ui.theme.IosShadowBlue
import com.tabletlauncher.ui.theme.IosSurfaceDark
import com.tabletlauncher.ui.theme.TextSecondary
import com.tabletlauncher.ui.theme.TextTertiary

/**
 * iPadOS-style Control Center:
 * 1. Slides in from top-right with smooth spring animation.
 * 2. Floating frosted glass panel (~380dp wide, 20dp corner radius).
 * 3. In landscape: top-right corner with 16dp margin. In portrait: top-center.
 * 4. Top Row:
 *    - Left: 2x2 Connectivity card (Airplane, Wi-Fi, Bluetooth, AirDrop).
 *    - Right: 2x1 vertical stack (Music Now Playing & Screen Mirroring).
 * 5. Middle Row:
 *    - Icon-only toggles: Lock Rotation, Do Not Disturb, Dark Mode.
 * 6. Bottom Section:
 *    - Two vertical sliders side by side (Brightness & Volume) filled from bottom-up.
 * 7. Tappable stateful controls.
 * 8. Dismiss on outside click or upward swipe.
 */
@Composable
fun ControlCenter(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    isAirplaneMode: Boolean,
    isWifiEnabled: Boolean,
    isBluetoothEnabled: Boolean,
    isAirDropEnabled: Boolean,
    isRotationLocked: Boolean,
    isDoNotDisturb: Boolean,
    isDarkMode: Boolean,
    isScreenMirroring: Boolean,
    brightness: Float,
    volume: Float,
    onToggleAirplaneMode: () -> Unit,
    onToggleWifi: () -> Unit,
    onToggleBluetooth: () -> Unit,
    onToggleAirDrop: () -> Unit,
    onToggleRotationLock: () -> Unit,
    onToggleDoNotDisturb: () -> Unit,
    onToggleDarkMode: () -> Unit,
    onToggleScreenMirroring: () -> Unit,
    onBrightnessChange: (Float) -> Unit,
    onVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val orientation = LocalDeviceOrientation.current

    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)),
        exit = fadeOut(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        // Scrim backdrop
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.35f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            // Floating Control Center panel
            AnimatedVisibility(
                visible = isOpen,
                enter = slideInVertically(
                    initialOffsetY = { -it },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    )
                ),
                exit = slideOutVertically(
                    targetOffsetY = { -it },
                    animationSpec = spring(stiffness = Spring.StiffnessMedium)
                ),
                modifier = Modifier
                    .then(
                        if (orientation == DeviceOrientation.Landscape) {
                            Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 16.dp, end = 16.dp)
                        } else {
                            Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 16.dp)
                        }
                    )
            ) {
                FrostedGlassBox(
                    modifier = Modifier
                        .width(380.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { /* Consume clicks so panel doesn't dismiss */ }
                        .pointerInput(Unit) {
                            detectVerticalDragGestures { _, dragAmount ->
                                if (dragAmount < -15f) {
                                    onDismiss()
                                }
                            }
                        },
                    shape = RoundedCornerShape(20.dp),
                    backgroundColor = IosSurfaceDark.copy(alpha = 0.85f),
                    borderColor = FrostedGlassBorder,
                    borderWidth = 0.5.dp,
                    elevation = 12.dp,
                    shadowColor = IosShadowBlue
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // 1. TOP ROW: Connectivity (2x2) + Vertical Stack (Music + Mirroring)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Left: 2x2 Connectivity Tile
                            ConnectivityTile(
                                isAirplaneMode = isAirplaneMode,
                                isWifiEnabled = isWifiEnabled,
                                isBluetoothEnabled = isBluetoothEnabled,
                                isAirDropEnabled = isAirDropEnabled,
                                onToggleAirplaneMode = onToggleAirplaneMode,
                                onToggleWifi = onToggleWifi,
                                onToggleBluetooth = onToggleBluetooth,
                                onToggleAirDrop = onToggleAirDrop,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(168.dp)
                            )

                            // Right: Media / Now Playing + Screen Mirroring (2x1 vertical stack)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(168.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                MediaTile(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(78.dp)
                                )
                                ScreenMirroringTile(
                                    isMirroring = isScreenMirroring,
                                    onToggle = onToggleScreenMirroring,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(78.dp)
                                )
                            }
                        }

                        // 2. MIDDLE ROW: Single-row icon-only toggle buttons (8dp / 16dp rounded corners)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconToggleButton(
                                icon = Icons.Default.ScreenLockRotation,
                                label = "Lock Rotation",
                                isActive = isRotationLocked,
                                activeColor = IosRed, // iOS red (#FF3B30)
                                onClick = onToggleRotationLock,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            IconToggleButton(
                                icon = Icons.Default.Nightlight,
                                label = "Do Not Disturb",
                                isActive = isDoNotDisturb,
                                activeColor = Color(0xFF5856D6), // iOS Purple
                                onClick = onToggleDoNotDisturb,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            IconToggleButton(
                                icon = Icons.Default.Brightness4,
                                label = "Dark Mode",
                                isActive = isDarkMode,
                                activeColor = IosBlue, // iOS blue (#007AFF)
                                onClick = onToggleDarkMode,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // 3. BOTTOM SECTION: Brightness & Volume Vertical Sliders
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(135.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            VerticalSlider(
                                value = brightness,
                                onValueChange = onBrightnessChange,
                                icon = Icons.Default.WbSunny,
                                contentDescription = "Brightness",
                                modifier = Modifier.weight(1f)
                            )

                            VerticalSlider(
                                value = volume,
                                onValueChange = onVolumeChange,
                                icon = if (volume > 0.05f) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                                contentDescription = "Volume",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2x2 Large Connectivity Tile for Airplane Mode, Wi-Fi, Bluetooth, and AirDrop.
 */
@Composable
private fun ConnectivityTile(
    isAirplaneMode: Boolean,
    isWifiEnabled: Boolean,
    isBluetoothEnabled: Boolean,
    isAirDropEnabled: Boolean,
    onToggleAirplaneMode: () -> Unit,
    onToggleWifi: () -> Unit,
    onToggleBluetooth: () -> Unit,
    onToggleAirDrop: () -> Unit,
    modifier: Modifier = Modifier
) {
    FrostedGlassBox(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        backgroundColor = FrostedGlassBackground,
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceAround
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                ConnectivityButton(
                    icon = Icons.Default.AirplanemodeActive,
                    label = "Airplane",
                    isActive = isAirplaneMode,
                    activeColor = Color(0xFFFF9500), // iOS Orange
                    onClick = onToggleAirplaneMode
                )
                ConnectivityButton(
                    icon = Icons.Default.Wifi,
                    label = if (isWifiEnabled) "Wi-Fi" else "Off",
                    isActive = isWifiEnabled,
                    activeColor = IosBlue, // iOS blue (#007AFF)
                    onClick = onToggleWifi
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                ConnectivityButton(
                    icon = Icons.Default.Bluetooth,
                    label = "Bluetooth",
                    isActive = isBluetoothEnabled,
                    activeColor = IosBlue, // iOS blue (#007AFF)
                    onClick = onToggleBluetooth
                )
                ConnectivityButton(
                    icon = Icons.Default.NearMe,
                    label = "AirDrop",
                    isActive = isAirDropEnabled,
                    activeColor = IosBlue, // iOS blue (#007AFF)
                    onClick = onToggleAirDrop
                )
            }
        }
    }
}

@Composable
private fun ConnectivityButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(if (isActive) activeColor else Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(19.dp)
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            style = TextStyle(
                fontFamily = InterFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.90f)
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Media / Music Tile showing "Not Playing".
 */
@Composable
private fun MediaTile(
    modifier: Modifier = Modifier
) {
    FrostedGlassBox(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        backgroundColor = FrostedGlassBackground,
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Small button shape: 8dp rounded corners
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Music",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Text(
                        text = "Music",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal,
                            color = TextSecondary
                        )
                    )
                    Text(
                        text = "Not Playing",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Play",
                tint = TextTertiary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * Screen Mirroring Tile.
 */
@Composable
private fun ScreenMirroringTile(
    isMirroring: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    FrostedGlassBox(
        modifier = modifier.clickable { onToggle() },
        shape = RoundedCornerShape(16.dp),
        backgroundColor = if (isMirroring) IosBlue else FrostedGlassBackground,
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Small button shape: 8dp rounded corners
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Cast,
                    contentDescription = "Screen Mirroring",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = "Screen Mirroring",
                style = TextStyle(
                    fontFamily = InterFontFamily,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Single-row icon-only toggle button with 16dp rounded corners.
 */
@Composable
private fun IconToggleButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FrostedGlassBox(
        modifier = modifier
            .height(52.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        shape = RoundedCornerShape(16.dp),
        backgroundColor = if (isActive) activeColor else FrostedGlassBackground,
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

/**
 * Vertical slider with bottom-up fill based on value (0f to 1f) and draggable interaction.
 * Rounded corner: 16dp, Frosted glass background: Color.White.copy(alpha = 0.15f), 0.5dp border.
 */
@Composable
private fun VerticalSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    icon: ImageVector,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(FrostedGlassBackground)
            .border(0.5.dp, FrostedGlassBorder, RoundedCornerShape(16.dp))
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, dragAmount ->
                    change.consume()
                    val delta = -dragAmount / size.height
                    onValueChange((value + delta).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val newValue = 1f - (offset.y / size.height)
                    onValueChange(newValue.coerceIn(0f, 1f))
                }
            }
    ) {
        val totalHeight = maxHeight
        val fillHeight = totalHeight * value.coerceIn(0f, 1f)

        // White bottom-up fill
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(fillHeight)
                .align(Alignment.BottomCenter)
                .background(Color.White.copy(alpha = 0.90f))
        )

        // Icon at the bottom (dynamically dark if fill covers the bottom, white otherwise)
        val isCoveredByFill = value > 0.16f
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 14.dp)
                .align(Alignment.BottomCenter),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (isCoveredByFill) IosSurfaceDark else Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
