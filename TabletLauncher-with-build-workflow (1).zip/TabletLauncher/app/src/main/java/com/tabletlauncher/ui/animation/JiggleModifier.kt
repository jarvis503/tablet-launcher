package com.tabletlauncher.ui.animation

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.abs

/**
 * Modifier that applies continuous iPadOS-style "jiggle" rotation animation to icons and widgets.
 *
 * Characteristics:
 * 1. Rotates between -2.0° and +2.0°.
 * 2. Infinite repeating animation with ~150ms period (varied between 140ms and 170ms by [seed]).
 * 3. Out-of-sync phases per item based on [seed] so items do not move synchronously.
 */
@Composable
fun Modifier.jiggle(
    isJiggleMode: Boolean,
    seed: Int = 0
): Modifier {
    if (!isJiggleMode) return this

    val infiniteTransition = rememberInfiniteTransition(label = "jiggle_transition_$seed")

    // Slight duration variation per item (140ms - 170ms) to prevent robotic synchronized jiggling
    val duration = 140 + (abs(seed) % 30)

    // Alternate starting angle direction per item
    val startAngle = if (abs(seed) % 2 == 0) -2.0f else 2.0f
    val targetAngle = -startAngle

    val rotation by infiniteTransition.animateFloat(
        initialValue = startAngle,
        targetValue = targetAngle,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = duration, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "jiggle_rotation_$seed"
    )

    return this.graphicsLayer {
        rotationZ = rotation
    }
}
