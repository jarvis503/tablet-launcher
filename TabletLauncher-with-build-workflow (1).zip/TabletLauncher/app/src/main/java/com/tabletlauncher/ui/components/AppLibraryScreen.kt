package com.tabletlauncher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tabletlauncher.data.model.AppCategorizer
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.ui.layout.DeviceOrientation
import com.tabletlauncher.ui.layout.LocalDeviceOrientation
import com.tabletlauncher.ui.theme.FrostedGlassBackground
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.theme.IosShadowBlue
import com.tabletlauncher.ui.theme.IosSurfaceDark
import com.tabletlauncher.ui.theme.TextSecondary
import com.tabletlauncher.ui.theme.TextTertiary

private val CategoryTitleShadow = Shadow(
    color = Color.Black.copy(alpha = 0.5f),
    offset = Offset(0f, 1f),
    blurRadius = 2f
)

/**
 * Fullscreen iPadOS-style App Library screen:
 * 1. 40dp rounded pill search bar at top (frosted glass, 12dp radius, 24dp horizontal padding).
 * 2. 2 columns (portrait) or 3 columns (landscape) of auto-generated category cards.
 * 3. Each category card: 16dp rounded rectangle with 2x2 mini-grid (top-right icon enlarged)
 *    and category title at bottom.
 * 4. Tapping card expands it into a frosted glass overlay showing all apps.
 * 5. Real-time search filters all apps by name and displays scrollable list of rows.
 */
@Composable
fun AppLibraryScreen(
    allApps: List<AppInfo>,
    onAppClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
    onAppLongClick: ((AppInfo) -> Unit)? = null
) {
    val context = LocalContext.current
    val orientation = LocalDeviceOrientation.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }

    // Auto-generate categories based on package category and heuristics
    val categorizedApps = remember(allApps, context) {
        AppCategorizer.groupApps(allApps, context)
    }

    // Real-time search filter
    val searchResults = remember(allApps, searchQuery) {
        if (searchQuery.isBlank()) {
            emptyList()
        } else {
            allApps.filter { app ->
                app.label.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. Top Search Bar: 40dp tall, 24dp horizontal padding, 12dp radius
            AppLibrarySearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                onClearQuery = { searchQuery = "" },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
            )

            // 2. Content: Search Results List OR Empty State OR Auto-Generated Categories Grid
            if (searchQuery.isNotBlank()) {
                SearchResultsList(
                    results = searchResults,
                    query = searchQuery,
                    onAppClick = onAppClick,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 8.dp)
                )
            } else if (allApps.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    FrostedGlassBox(
                        modifier = Modifier.size(64.dp),
                        shape = CircleShape,
                        backgroundColor = Color.White.copy(alpha = 0.15f),
                        borderColor = FrostedGlassBorder,
                        borderWidth = 0.5.dp,
                        elevation = 8.dp,
                        shadowColor = IosShadowBlue
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "App Library Empty",
                        fontFamily = InterFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Installed applications will automatically be organized here.",
                        fontFamily = InterFontFamily,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // Responsive Columns: 2 columns in Portrait, 3 columns in Landscape
                val columns = if (orientation == DeviceOrientation.Landscape) 3 else 2

                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    contentPadding = PaddingValues(top = 10.dp, bottom = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(categorizedApps.keys.toList(), key = { it }) { categoryName ->
                        val appsInCategory = categorizedApps[categoryName] ?: emptyList()
                        CategoryCard(
                            categoryName = categoryName,
                            apps = appsInCategory,
                            onCardClick = {
                                selectedCategory = categoryName
                            },
                            onDirectAppClick = onAppClick
                        )
                    }
                }
            }
        }

        // 3. Category Expansion Grid Overlay
        selectedCategory?.let { categoryName ->
            val apps = categorizedApps[categoryName] ?: emptyList()
            CategoryExpandedOverlay(
                categoryName = categoryName,
                apps = apps,
                onDismiss = { selectedCategory = null },
                onAppClick = { app ->
                    selectedCategory = null
                    onAppClick(app)
                },
                onAppLongClick = onAppLongClick
            )
        }
    }
}

/**
 * iPadOS-style pill search bar.
 */
@Composable
private fun AppLibrarySearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onClearQuery: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Pill shape: half of 40dp height = 20dp
    Surface(
        modifier = modifier.height(40.dp),
        shape = RoundedCornerShape(20.dp),
        color = FrostedGlassBackground,
        border = BorderStroke(0.5.dp, FrostedGlassBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = TextSecondary,
                modifier = Modifier.size(18.dp)
            )

            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) {
                    Text(
                        text = "App Library",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontSize = 14.sp,
                            color = TextSecondary
                        )
                    )
                }

                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    ),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (query.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.25f))
                        .clickable { onClearQuery() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * 2x2 Category folder card with frosted glass background.
 * Top-right icon is enlarged (~48dp) and directly launches that app.
 */
@Composable
private fun CategoryCard(
    categoryName: String,
    apps: List<AppInfo>,
    onCardClick: () -> Unit,
    onDirectAppClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    FrostedGlassBox(
        modifier = modifier
            .fillMaxWidth()
            .height(175.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onCardClick
            ),
        shape = RoundedCornerShape(16.dp),
        backgroundColor = FrostedGlassBackground,
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp,
        elevation = 4.dp,
        shadowColor = IosShadowBlue
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 2x2 Mini-Grid of Top App Icons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Column: Icon 1 (top-left) & Icon 3 (bottom-left)
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    MiniAppIcon(
                        app = apps.getOrNull(0),
                        size = 38.dp,
                        cornerRadius = 9.dp,
                        onClick = { apps.getOrNull(0)?.let(onDirectAppClick) }
                    )
                    MiniAppIcon(
                        app = apps.getOrNull(2),
                        size = 38.dp,
                        cornerRadius = 9.dp,
                        onClick = { apps.getOrNull(2)?.let(onDirectAppClick) }
                    )
                }

                // Right Column: Icon 2 (top-right, slightly larger 48dp) & Icon 4/Folder (bottom-right)
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top-right icon: slightly larger (48dp), directly tappable
                    MiniAppIcon(
                        app = apps.getOrNull(1),
                        size = 48.dp,
                        cornerRadius = 11.dp,
                        onClick = { apps.getOrNull(1)?.let(onDirectAppClick) }
                    )

                    // Bottom-right slot: Icon 4 or 4-dot folder overflow indicator
                    if (apps.size > 4) {
                        OverflowFolderIcon(
                            overflowCount = apps.size - 3,
                            onClick = onCardClick
                        )
                    } else {
                        MiniAppIcon(
                            app = apps.getOrNull(3),
                            size = 36.dp,
                            cornerRadius = 8.dp,
                            onClick = { apps.getOrNull(3)?.let(onDirectAppClick) }
                        )
                    }
                }
            }

            // Category Name at bottom
            Text(
                text = categoryName,
                style = TextStyle(
                    fontFamily = InterFontFamily,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    shadow = CategoryTitleShadow
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun MiniAppIcon(
    app: AppInfo?,
    size: androidx.compose.ui.unit.Dp,
    cornerRadius: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit
) {
    if (app != null) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(cornerRadius))
                .clickable { onClick() }
        )
    } else {
        // Empty placeholder square if category has fewer apps
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(cornerRadius))
                .background(Color.White.copy(alpha = 0.08f))
        )
    }
}

@Composable
private fun OverflowFolderIcon(
    overflowCount: Int,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White.copy(alpha = 0.20f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(5.dp).background(Color.White, CircleShape))
            Box(modifier = Modifier.size(5.dp).background(Color.White, CircleShape))
            Box(modifier = Modifier.size(5.dp).background(Color.White, CircleShape))
        }
    }
}

/**
 * Frosted glass popup overlay displaying all apps in the expanded category.
 */
@Composable
private fun CategoryExpandedOverlay(
    categoryName: String,
    apps: List<AppInfo>,
    onDismiss: () -> Unit,
    onAppClick: (AppInfo) -> Unit,
    onAppLongClick: ((AppInfo) -> Unit)?
) {
    Dialog(onDismissRequest = onDismiss) {
        FrostedGlassBox(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 520.dp),
            shape = RoundedCornerShape(20.dp),
            backgroundColor = IosSurfaceDark.copy(alpha = 0.90f),
            borderColor = FrostedGlassBorder,
            borderWidth = 0.5.dp,
            elevation = 12.dp,
            shadowColor = IosShadowBlue
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header: Title (weight 600 SemiBold) & Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = categoryName,
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold, // Settings/Category header: weight 600
                            color = Color.White
                        )
                    )

                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.18f))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // All apps in category in a responsive grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    items(apps, key = { it.packageName }) { app ->
                        AppIconItem(
                            app = app,
                            onClick = { onAppClick(app) },
                            onLongClick = onAppLongClick?.let { { it(app) } }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Real-time scrollable search results list displaying app rows.
 */
@Composable
private fun SearchResultsList(
    results: List<AppInfo>,
    query: String,
    onAppClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    FrostedGlassBox(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        backgroundColor = FrostedGlassBackground,
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp,
        elevation = 4.dp,
        shadowColor = IosShadowBlue
    ) {
        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No apps found for \"$query\"",
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 15.sp,
                        color = Color.White.copy(alpha = 0.70f)
                    ),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(results, key = { it.packageName }) { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onAppClick(app) }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Image(
                            bitmap = app.icon,
                            contentDescription = app.label,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )

                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = app.label,
                                style = TextStyle(
                                    fontFamily = InterFontFamily,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = app.packageName,
                                style = TextStyle(
                                    fontFamily = InterFontFamily,
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.55f)
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.40f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
