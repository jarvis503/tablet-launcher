package com.tabletlauncher.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Canonical iPadOS Colors
val IosBlue = Color(0xFF007AFF)              // Active / selected items
val IosGreen = Color(0xFF34C759)             // Toggle on state
val IosRed = Color(0xFFFF3B30)               // Destructive actions
val IosSurfaceDark = Color(0xFF1C1C1E)       // Surfaces: avoid pure black, dark blue-gray
val IosShadowBlue = Color(0xFF0A0E1A)        // Dark blue tinted shadow
val TextSecondary = Color.White.copy(alpha = 0.60f) // Secondary text: 60% opacity
val TextTertiary = Color.White.copy(alpha = 0.40f)  // Tertiary text: 40% opacity
val FrostedGlassBackground = Color.White.copy(alpha = 0.15f) // Frosted glass dark mode
val FrostedGlassBorder = Color.White.copy(alpha = 0.10f)     // Thin 0.5dp border

// Legacy Launcher Palette
val LauncherAccent = IosBlue
val LauncherAccentDark = Color(0xFF5AC8FA)
val DarkBackground = Color(0xFF0A0E1A)
val DarkSurface = IosSurfaceDark
val DarkSurfaceVariant = Color(0xFF2C2C2E)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
