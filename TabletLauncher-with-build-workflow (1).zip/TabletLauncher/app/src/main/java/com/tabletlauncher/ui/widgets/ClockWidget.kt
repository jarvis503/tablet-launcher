package com.tabletlauncher.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.ui.theme.InterFontFamily
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Calendar

/**
 * iPadOS-style analog Clock Widget (Small 2x2):
 * 1. Analog clock face with 12 hour tick marks.
 * 2. Thin white hour and minute hands.
 * 3. Orange second hand updated every second via coroutine.
 * 4. Display city name below ("Cupertino" as default).
 */
@Composable
fun ClockWidget(
    cityName: String = "Cupertino",
    modifier: Modifier = Modifier
) {
    var calendar by remember { mutableStateOf(Calendar.getInstance()) }

    // Live update loop every second
    LaunchedEffect(Unit) {
        while (isActive) {
            calendar = Calendar.getInstance()
            delay(1000)
        }
    }

    val hours = calendar.get(Calendar.HOUR)
    val minutes = calendar.get(Calendar.MINUTE)
    val seconds = calendar.get(Calendar.SECOND)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Analog Clock Face Dial
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(100.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = (size.minDimension / 2f) - 2.dp.toPx()

                // Dial face background
                drawCircle(
                    color = Color.Black.copy(alpha = 0.22f),
                    radius = radius,
                    center = center
                )

                // Dial outer rim
                drawCircle(
                    color = Color.White.copy(alpha = 0.25f),
                    radius = radius,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // 12 Dial tick marks
                for (i in 0 until 12) {
                    val angleDeg = i * 30f - 90f
                    val angleRad = Math.toRadians(angleDeg.toDouble())
                    val isMajor = i % 3 == 0
                    val tickLen = if (isMajor) 7.dp.toPx() else 4.dp.toPx()
                    val strokeW = if (isMajor) 2.dp.toPx() else 1.dp.toPx()
                    val color = if (isMajor) Color.White else Color.White.copy(alpha = 0.50f)

                    val startX = (center.x + (radius - tickLen) * Math.cos(angleRad)).toFloat()
                    val startY = (center.y + (radius - tickLen) * Math.sin(angleRad)).toFloat()
                    val endX = (center.x + (radius - 2.dp.toPx()) * Math.cos(angleRad)).toFloat()
                    val endY = (center.y + (radius - 2.dp.toPx()) * Math.sin(angleRad)).toFloat()

                    drawLine(
                        color = color,
                        start = Offset(startX, startY),
                        end = Offset(endX, endY),
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )
                }

                // Hour Hand (white, rounded cap)
                val hourAngle = Math.toRadians(((hours % 12 + minutes / 60f) * 30f - 90f).toDouble())
                val hourHandLen = radius * 0.52f
                val hourEndX = (center.x + hourHandLen * Math.cos(hourAngle)).toFloat()
                val hourEndY = (center.y + hourHandLen * Math.sin(hourAngle)).toFloat()
                drawLine(
                    color = Color.White,
                    start = center,
                    end = Offset(hourEndX, hourEndY),
                    strokeWidth = 3.5.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Minute Hand (thin white hand)
                val minuteAngle = Math.toRadians(((minutes + seconds / 60f) * 6f - 90f).toDouble())
                val minuteHandLen = radius * 0.74f
                val minEndX = (center.x + minuteHandLen * Math.cos(minuteAngle)).toFloat()
                val minEndY = (center.y + minuteHandLen * Math.sin(minuteAngle)).toFloat()
                drawLine(
                    color = Color.White,
                    start = center,
                    end = Offset(minEndX, minEndY),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Second Hand (iPadOS orange)
                val secondAngle = Math.toRadians((seconds * 6f - 90f).toDouble())
                val secondHandLen = radius * 0.82f
                val secEndX = (center.x + secondHandLen * Math.cos(secondAngle)).toFloat()
                val secEndY = (center.y + secondHandLen * Math.sin(secondAngle)).toFloat()
                val secTailX = (center.x - radius * 0.18f * Math.cos(secondAngle)).toFloat()
                val secTailY = (center.y - radius * 0.18f * Math.sin(secondAngle)).toFloat()
                drawLine(
                    color = Color(0xFFFF9500),
                    start = Offset(secTailX, secTailY),
                    end = Offset(secEndX, secEndY),
                    strokeWidth = 1.5.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Center pivot cap
                drawCircle(
                    color = Color(0xFFFF9500),
                    radius = 3.dp.toPx(),
                    center = center
                )
                drawCircle(
                    color = Color.Black,
                    radius = 1.dp.toPx(),
                    center = center
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // City Name below
        Text(
            text = cityName,
            fontFamily = InterFontFamily,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White.copy(alpha = 0.90f),
            maxLines = 1
        )
    }
}
