package com.tabletlauncher.ui.layout

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Window width size classes based on Material 3 responsive design guidelines.
 */
enum class WindowWidthSizeClass {
    Compact,   // < 600dp (e.g. phones in portrait)
    Medium,    // 600dp - 839dp (e.g. foldables, small tablets)
    Expanded   // >= 840dp (e.g. large tablets, desktops)
}

/**
 * Window height size classes based on Material 3 responsive design guidelines.
 */
enum class WindowHeightSizeClass {
    Compact,   // < 480dp (e.g. phones in landscape)
    Medium,    // 480dp - 899dp (e.g. tablets in landscape, phones in portrait)
    Expanded   // >= 900dp (e.g. tablets in portrait)
}

/**
 * Represents the 2D window size class classification for responsive tablet layouts.
 */
data class WindowSizeClass(
    val widthSizeClass: WindowWidthSizeClass,
    val heightSizeClass: WindowHeightSizeClass
) {
    val isTablet: Boolean
        get() = widthSizeClass == WindowWidthSizeClass.Expanded ||
                (widthSizeClass == WindowWidthSizeClass.Medium && heightSizeClass == WindowHeightSizeClass.Expanded)

    companion object {
        fun calculate(widthDp: Dp, heightDp: Dp): WindowSizeClass {
            val widthClass = when {
                widthDp < 600.dp -> WindowWidthSizeClass.Compact
                widthDp < 840.dp -> WindowWidthSizeClass.Medium
                else -> WindowWidthSizeClass.Expanded
            }
            val heightClass = when {
                heightDp < 480.dp -> WindowHeightSizeClass.Compact
                heightDp < 900.dp -> WindowHeightSizeClass.Medium
                else -> WindowHeightSizeClass.Expanded
            }
            return WindowSizeClass(widthClass, heightClass)
        }
    }
}

/**
 * WindowSizeClass detector that observes the current configuration and computes
 * the width and height size classes.
 */
@Composable
fun rememberWindowSizeClass(): WindowSizeClass {
    val configuration = LocalConfiguration.current
    return WindowSizeClass.calculate(
        widthDp = configuration.screenWidthDp.dp,
        heightDp = configuration.screenHeightDp.dp
    )
}

/**
 * CompositionLocal providing the current [WindowSizeClass].
 */
val LocalWindowSizeClass = compositionLocalOf {
    WindowSizeClass(WindowWidthSizeClass.Expanded, WindowHeightSizeClass.Expanded)
}
