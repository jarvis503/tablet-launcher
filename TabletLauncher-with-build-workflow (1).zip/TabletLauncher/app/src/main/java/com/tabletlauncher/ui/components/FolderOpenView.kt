package com.tabletlauncher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.data.model.AppFolder
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.ui.layout.DeviceOrientation
import com.tabletlauncher.ui.layout.LocalDeviceOrientation
import com.tabletlauncher.ui.theme.FrostedGlassBackground
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.theme.IosShadowBlue
import com.tabletlauncher.ui.theme.IosSurfaceDark
import kotlinx.coroutines.launch

private val FolderCardShape = RoundedCornerShape(20.dp)

/**
 * iPadOS-style open folder overlay view.
 *
 * Characteristics:
 * 1. Background dim with 40% black overlay.
 * 2. Expanding frosted glass card with 20dp corner radius and spring animation.
 * 3. Editable folder title at the top using [BasicTextField].
 * 4. Internal app grid: 3x3 in portrait (9 apps/page) and 4x3 in landscape (12 apps/page).
 * 5. Horizontal paging with indicator dots if folder contains more apps than single-page capacity.
 * 6. Launches app on tap, closes on tapping outside.
 */
@Composable
fun FolderOpenView(
    folder: AppFolder?,
    onDismiss: () -> Unit,
    onAppClick: (AppInfo, Rect?) -> Unit,
    onRenameFolder: (String) -> Unit,
    modifier: Modifier = Modifier,
    onAppLongClick: ((AppInfo) -> Unit)? = null
) {
    // Preserve last non-null folder during exit animation
    var cachedFolder by remember { mutableStateOf<AppFolder?>(null) }
    if (folder != null) {
        cachedFolder = folder
    }

    val isVisible = folder != null
    val targetFolder = folder ?: cachedFolder

    AnimatedVisibility(
        visible = isVisible && targetFolder != null,
        enter = fadeIn(animationSpec = tween(220)),
        exit = fadeOut(animationSpec = tween(180)),
        modifier = modifier.fillMaxSize()
    ) {
        val currentFolder = targetFolder ?: return@AnimatedVisibility

        // Spring expansion animation for the folder card
        val cardScale by animateFloatAsState(
            targetValue = if (isVisible) 1f else 0.70f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "folder_open_card_scale"
        )

        // Dim background (40% black overlay) with tap-outside dismissal
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.40f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    onDismiss()
                },
            contentAlignment = Alignment.Center
        ) {
            FolderCardContent(
                folder = currentFolder,
                scale = cardScale,
                onAppClick = onAppClick,
                onRenameFolder = onRenameFolder,
                onAppLongClick = onAppLongClick
            )
        }
    }
}

/**
 * Frosted glass card content displaying the editable title and paged grid of apps.
 */
@Composable
private fun FolderCardContent(
    folder: AppFolder,
    scale: Float,
    onAppClick: (AppInfo, Rect?) -> Unit,
    onRenameFolder: (String) -> Unit,
    onAppLongClick: ((AppInfo) -> Unit)?
) {
    val orientation = LocalDeviceOrientation.current
    val isLandscape = orientation == DeviceOrientation.Landscape
    val focusManager = LocalFocusManager.current
    val coroutineScope = rememberCoroutineScope()

    // Grid capacity: 3x3 in portrait (9 apps/page), 4x3 in landscape (12 apps/page)
    val columns = if (isLandscape) 4 else 3
    val appsPerPage = if (isLandscape) 12 else 9

    // Card dimensions tailored to orientation
    val cardWidth = if (isLandscape) 460.dp else 370.dp
    val cardHeight = if (isLandscape) 440.dp else 470.dp

    // Chunk folder apps into pages
    val folderPages = remember(folder.apps.toList(), appsPerPage) {
        if (folder.apps.isEmpty()) {
            listOf(emptyList())
        } else {
            folder.apps.chunked(appsPerPage)
        }
    }

    val pageCount = folderPages.size
    val pagerState = rememberPagerState(initialPage = 0) { pageCount }

    // Synchronize title text field with folder name
    var titleText by remember(folder.id, folder.name) {
        mutableStateOf(folder.name)
    }

    FrostedGlassBox(
        modifier = Modifier
            .size(width = cardWidth, height = cardHeight)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                // Consume clicks inside the card so tapping inside does not close the folder
                focusManager.clearFocus()
            }
            .padding(vertical = 20.dp, horizontal = 16.dp),
        shape = FolderCardShape,
        backgroundColor = IosSurfaceDark.copy(alpha = 0.88f),
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp,
        elevation = 12.dp,
        shadowColor = IosShadowBlue,
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Editable Folder Name Header: weight 600 (SemiBold)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                BasicTextField(
                    value = titleText,
                    onValueChange = { newText ->
                        titleText = newText
                        onRenameFolder(newText.ifBlank { "Folder" })
                    },
                    textStyle = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold, // Weight 600 (SemiBold)
                        color = Color.White,
                        textAlign = TextAlign.Center
                    ),
                    singleLine = true,
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val resolvedName = titleText.trim().ifBlank { "Folder" }
                            titleText = resolvedName
                            onRenameFolder(resolvedName)
                            focusManager.clearFocus()
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Apps Pager inside the folder
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { pageIndex ->
                    val pageApps = folderPages.getOrElse(pageIndex) { emptyList() }
                    val rowChunks = remember(pageApps, columns) {
                        pageApps.chunked(columns)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalArrangement = Arrangement.SpaceEvenly,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        rowChunks.forEach { rowApps ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                rowApps.forEach { app ->
                                    AppIconItem(
                                        app = app,
                                        onClick = { onAppClick(app, null) },
                                        onClickWithBounds = { a, bounds -> onAppClick(a, bounds) },
                                        onLongClick = onAppLongClick?.let { { it(app) } }
                                    )
                                }

                                // Pad partial rows to maintain grid column alignment
                                val emptySlots = columns - rowApps.size
                                repeat(emptySlots) {
                                    Spacer(modifier = Modifier.width(60.dp))
                                }
                            }
                        }

                        // Pad empty rows if page has fewer rows to maintain consistent vertical layout
                        val emptyRows = 3 - rowChunks.size
                        repeat(emptyRows) {
                            Spacer(modifier = Modifier.height(70.dp))
                        }
                    }
                }
            }

            // Indicator dots if folder contains more apps than a single page
            if (pageCount > 1) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    repeat(pageCount) { dotIndex ->
                        val isCurrent = pagerState.currentPage == dotIndex
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) {
                                    coroutineScope.launch {
                                        pagerState.animateScrollToPage(dotIndex)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCurrent) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(
                                            Brush.radialGradient(
                                                colors = listOf(
                                                    Color.White.copy(alpha = 0.55f),
                                                    Color.Transparent
                                                )
                                            ),
                                            shape = CircleShape
                                        )
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(
                                        color = if (isCurrent) Color.White else Color.White.copy(alpha = 0.40f),
                                        shape = CircleShape
                                    )
                            )
                        }
                    }
                }
            }
        }
    }
}
