package com.tabletlauncher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.ui.layout.DeviceOrientation
import com.tabletlauncher.ui.layout.LocalDeviceOrientation
import com.tabletlauncher.ui.theme.FrostedGlassBackground
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.theme.IosShadowBlue
import com.tabletlauncher.ui.theme.IosSurfaceDark
import com.tabletlauncher.ui.theme.TextSecondary
import com.tabletlauncher.ui.theme.TextTertiary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Data model for mock notification items.
 */
data class MockNotification(
    val id: String,
    val appName: String,
    val appIcon: ImageVector,
    val iconTint: Color,
    val timestamp: String,
    val title: String,
    val body: String
)

/**
 * iPadOS-style Notification Center:
 * - Slides in smoothly from top.
 * - Landscape: covers left ~45% of the screen width.
 * - Portrait: covers full screen width.
 * - Large day of week & date at top.
 * - Dismissible notification cards with swipe-to-dismiss.
 * - "No Older Notifications" centered below.
 * - Closes on upward swipe or tap on backdrop scrim.
 */
@Composable
fun NotificationCenter(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orientation = LocalDeviceOrientation.current

    // Mock initial notifications list
    val notifications = remember {
        mutableStateListOf(
            MockNotification(
                id = "1",
                appName = "Messages",
                appIcon = Icons.Default.Chat,
                iconTint = Color(0xFF34D399), // Emerald
                timestamp = "10m ago",
                title = "Sarah Jenkins",
                body = "Hey! Are you still joining for the design review meeting this afternoon?"
            ),
            MockNotification(
                id = "2",
                appName = "Calendar",
                appIcon = Icons.Default.CalendarToday,
                iconTint = Color(0xFFF87171), // Coral
                timestamp = "35m ago",
                title = "Product Roadmap Sync",
                body = "Starting in 15 minutes in Boardroom 2B & Google Meet."
            ),
            MockNotification(
                id = "3",
                appName = "Mail",
                appIcon = Icons.Default.Mail,
                iconTint = Color(0xFF60A5FA), // Blue
                timestamp = "1h ago",
                title = "GitHub Security Alert",
                body = "New sign-in detected from Chrome on Windows in California, US."
            ),
            MockNotification(
                id = "4",
                appName = "Reminders",
                appIcon = Icons.Default.CheckCircle,
                iconTint = Color(0xFFFBBF24), // Amber
                timestamp = "2h ago",
                title = "Order Tablet Stand",
                body = "Check compatibility with 11-inch & 13-inch iPadOS style tablets."
            )
        )
    }

    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)),
        exit = fadeOut(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.40f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
        ) {
            // Slide in the panel from top
            AnimatedVisibility(
                visible = isOpen,
                enter = slideInVertically(
                    initialOffsetY = { -it },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    )
                ),
                exit = slideOutVertically(
                    targetOffsetY = { -it },
                    animationSpec = spring(stiffness = Spring.StiffnessMedium)
                ),
                modifier = Modifier
                    .fillMaxHeight()
                    .then(
                        if (orientation == DeviceOrientation.Landscape) {
                            Modifier.fillMaxWidth(0.45f)
                        } else {
                            Modifier.fillMaxWidth()
                        }
                    )
                    .align(Alignment.CenterStart)
            ) {
                NotificationPanel(
                    notifications = notifications,
                    onNotificationDismiss = { item -> notifications.remove(item) },
                    onCloseSwipe = onDismiss
                )
            }
        }
    }
}

/**
 * The frosted glass notification center panel content.
 */
@Composable
private fun NotificationPanel(
    notifications: List<MockNotification>,
    onNotificationDismiss: (MockNotification) -> Unit,
    onCloseSwipe: () -> Unit
) {
    val currentTime = remember { SimpleDateFormat("h:mm", Locale.getDefault()).format(Date()) }
    val dayOfWeek = remember { SimpleDateFormat("EEEE", Locale.getDefault()).format(Date()) }
    val fullDate = remember { SimpleDateFormat("MMMM d", Locale.getDefault()).format(Date()) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { /* Consume clicks inside panel so scrim doesn't close accidentally */ }
            .pointerInput(Unit) {
                // Close when user swipes up
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount < -15f) {
                        onCloseSwipe()
                    }
                }
            },
        color = IosSurfaceDark.copy(alpha = 0.85f),
        border = BorderStroke(0.5.dp, FrostedGlassBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 24.dp)
        ) {
            // Top pull handle bar (subtle visual indicator)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 36.dp, height = 4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.35f))
                )
            }

            // 1. Lock screen time: weight 200 (Thin/UltraLight) + Date
            Column(
                modifier = Modifier.padding(bottom = 20.dp)
            ) {
                Text(
                    text = currentTime,
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 68.sp,
                        fontWeight = FontWeight.ExtraLight, // Weight 200 (Thin/UltraLight)
                        color = Color.White,
                        letterSpacing = (-1.5).sp
                    )
                )
                Text(
                    text = "$dayOfWeek, $fullDate",
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.90f)
                    )
                )
            }

            // 2. Notification Cards List (with swipe-to-dismiss)
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(
                    items = notifications,
                    key = { it.id }
                ) { notification ->
                    NotificationCardItem(
                        notification = notification,
                        onDismiss = { onNotificationDismiss(notification) }
                    )
                }

                // 3. "No Older Notifications" centered message below cards
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "No Older Notifications",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextTertiary
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

/**
 * Single dismissible notification card.
 * Cards: 16dp rounded corners, Color.White.copy(alpha = 0.15f), thin 0.5dp border of Color.White.copy(alpha = 0.10f).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationCardItem(
    notification: MockNotification,
    onDismiss: () -> Unit
) {
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (value == SwipeToDismissBoxValue.StartToEnd || value == SwipeToDismissBoxValue.EndToStart) {
                onDismiss()
                true
            } else {
                false
            }
        }
    )

    SwipeToDismissBox(
        state = dismissState,
        backgroundContent = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFFF3B30).copy(alpha = 0.35f))
            )
        }
    ) {
        FrostedGlassBox(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            backgroundColor = FrostedGlassBackground,
            borderColor = FrostedGlassBorder,
            borderWidth = 0.5.dp,
            elevation = 4.dp,
            shadowColor = IosShadowBlue
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                // Top row: App Icon (20dp) + App Name + Timestamp
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(4.4.dp))
                                .background(notification.iconTint),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = notification.appIcon,
                                contentDescription = notification.appName,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }

                        Text(
                            text = notification.appName,
                            style = TextStyle(
                                fontFamily = InterFontFamily,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White.copy(alpha = 0.90f)
                            )
                        )
                    }

                    // Tertiary text: white at 40% opacity
                    Text(
                        text = notification.timestamp,
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal,
                            color = TextTertiary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Notification Title in bold white
                Text(
                    text = notification.title,
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(3.dp))

                // Notification Body in secondary text (white at 60% opacity)
                Text(
                    text = notification.body,
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        color = TextSecondary
                    )
                )
            }
        }
    }
}
