package com.tabletlauncher.data.model

import androidx.compose.ui.graphics.ImageBitmap

/**
 * Represents an installed application on the device.
 *
 * @property packageName Unique application package identifier.
 * @property label User-facing display name of the application.
 * @property icon Renderable [ImageBitmap] of the app icon.
 * @property isSystemApp True if the app is pre-installed in the Android system partition.
 */
data class AppInfo(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap,
    val isSystemApp: Boolean
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is AppInfo) return false
        return packageName == other.packageName
    }

    override fun hashCode(): Int = packageName.hashCode()
}
