package com.tabletlauncher.data.model

import java.util.UUID

/**
 * Grid footprint sizes for iPadOS-style home screen widgets.
 *
 * @property colSpan Number of grid columns occupied.
 * @property rowSpan Number of grid rows occupied.
 */
enum class WidgetSize(val colSpan: Int, val rowSpan: Int) {
    Small(colSpan = 2, rowSpan = 2),
    Medium(colSpan = 4, rowSpan = 2),
    Large(colSpan = 4, rowSpan = 4);

    /**
     * Total number of 1x1 cells occupied on the home screen grid.
     */
    val cellCount: Int get() = colSpan * rowSpan
}

/**
 * Supported built-in widget types.
 */
enum class WidgetType(val defaultSize: WidgetSize) {
    Clock(WidgetSize.Small),
    Weather(WidgetSize.Medium),
    Calendar(WidgetSize.Medium),
    Battery(WidgetSize.Small)
}

/**
 * Represents a built-in widget placed on a home screen page.
 *
 * @property id Unique identifier for the widget instance.
 * @property type Type of widget (Clock, Weather, Calendar, Battery).
 * @property size Footprint size (Small 2x2, Medium 4x2, Large 4x4).
 * @property title User-facing title of the widget.
 */
data class WidgetInfo(
    val id: String = UUID.randomUUID().toString(),
    val type: WidgetType,
    val size: WidgetSize = when (type) {
        WidgetType.Clock -> WidgetSize.Small
        WidgetType.Weather -> WidgetSize.Medium
        WidgetType.Calendar -> WidgetSize.Medium
        WidgetType.Battery -> WidgetSize.Small
    },
    val title: String = type.name
)
