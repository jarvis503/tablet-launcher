package com.tabletlauncher.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.tabletlauncher.data.model.AppFolder
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.data.model.HomeScreenItem
import com.tabletlauncher.data.model.WidgetInfo
import com.tabletlauncher.ui.layout.DeviceOrientation
import com.tabletlauncher.ui.layout.LauncherDimens
import com.tabletlauncher.ui.layout.LocalDeviceOrientation
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.theme.IosShadowBlue
import com.tabletlauncher.ui.theme.TextSecondary
import com.tabletlauncher.ui.widgets.LauncherWidget
import com.tabletlauncher.ui.widgets.WidgetContent
import com.tabletlauncher.wallpaper.WallpaperManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Data structure representing a grid-placed item with column/row spans and coordinates.
 */
data class PlacedGridItem(
    val item: HomeScreenItem,
    val col: Int,
    val row: Int,
    val colSpan: Int,
    val rowSpan: Int
)

/**
 * Places items into a 2D grid matrix:
 * - Widgets occupy multiple cells according to their size (e.g. 2x2, 4x2, 4x4).
 * - App and folder items occupy 1x1 cells.
 * - Fits items into the earliest available slot in top-to-bottom, left-to-right order.
 */
fun layoutGridPage(
    items: List<HomeScreenItem>,
    columns: Int,
    rows: Int
): List<PlacedGridItem> {
    val occupied = Array(columns) { BooleanArray(rows) }
    val placed = mutableListOf<PlacedGridItem>()

    for (item in items) {
        val (colSpan, rowSpan) = when (item) {
            is HomeScreenItem.WidgetItem -> {
                val cs = item.widget.size.colSpan.coerceAtMost(columns)
                val rs = item.widget.size.rowSpan.coerceAtMost(rows)
                Pair(cs, rs)
            }
            else -> Pair(1, 1)
        }

        // Search for first position (col, row) where colSpan x rowSpan fits
        var foundPos: Pair<Int, Int>? = null
        findSlot@ for (r in 0..(rows - rowSpan)) {
            for (c in 0..(columns - colSpan)) {
                var isFree = true
                checkBlock@ for (dr in 0 until rowSpan) {
                    for (dc in 0 until colSpan) {
                        if (occupied[c + dc][r + dr]) {
                            isFree = false
                            break@checkBlock
                        }
                    }
                }
                if (isFree) {
                    foundPos = Pair(c, r)
                    break@findSlot
                }
            }
        }

        if (foundPos != null) {
            val (c, r) = foundPos
            for (dr in 0 until rowSpan) {
                for (dc in 0 until colSpan) {
                    occupied[c + dc][r + dr] = true
                }
            }
            placed.add(PlacedGridItem(item, c, r, colSpan, rowSpan))
        }
    }
    return placed
}

/**
 * Home screen page system with horizontal swipe navigation supporting app icons, folders,
 * built-in iPadOS widgets, and Jiggle Mode (edit mode).
 *
 * Characteristics:
 * 1. HorizontalPager for smooth swipe navigation between home pages.
 * 2. 2D grid layout supporting multi-cell widget footprints.
 * 3. Jiggle Mode:
 *    - Continuous rotation between -2° and +2° with out-of-sync phases.
 *    - "X" delete badge on app icons and minus badge on widgets.
 *    - Drag-and-drop icon rearrangement with smooth sliding.
 *    - Dragging over another app creates a folder after 500ms.
 *    - Dragging to page edges moves item across pages.
 *    - Wallpaper tap dismisses Jiggle Mode.
 * 4. Captures root bounds on launch tap for smooth iPadOS expansion animation.
 */
@Composable
fun HomeScreenPager(
    allApps: List<AppInfo>,
    onAppClick: (AppInfo, Rect?) -> Unit,
    modifier: Modifier = Modifier,
    homePages: Map<Int, List<HomeScreenItem>>? = null,
    isJiggleMode: Boolean = false,
    onFolderClick: ((AppFolder) -> Unit)? = null,
    onWidgetClick: ((WidgetInfo) -> Unit)? = null,
    onAppLongClick: ((AppInfo) -> Unit)? = null,
    onFolderLongClick: ((AppFolder) -> Unit)? = null,
    onWidgetLongClick: ((WidgetInfo) -> Unit)? = null,
    onDeleteApp: ((AppInfo) -> Unit)? = null,
    onDeleteFolder: ((AppFolder) -> Unit)? = null,
    onDeleteWidget: ((WidgetInfo) -> Unit)? = null,
    onReorderItems: ((pageIndex: Int, fromIndex: Int, toIndex: Int) -> Unit)? = null,
    onCreateFolderFromDrop: ((sourceApp: AppInfo, targetApp: AppInfo) -> Unit)? = null,
    onMoveItemToPage: ((fromPage: Int, itemId: String, toPage: Int) -> Unit)? = null,
    onBackgroundClick: (() -> Unit)? = null,
    onTriggerSpotlight: (() -> Unit)? = null,
    includeAppLibrary: Boolean = true
) {
    val orientation = LocalDeviceOrientation.current
    val coroutineScope = rememberCoroutineScope()

    // Grid sizing based on device orientation
    val columns = if (orientation == DeviceOrientation.Landscape) {
        LauncherDimens.LANDSCAPE_COLUMNS // 7
    } else {
        LauncherDimens.PORTRAIT_COLUMNS  // 5
    }

    val rows = if (orientation == DeviceOrientation.Landscape) {
        LauncherDimens.LANDSCAPE_ROWS    // 4
    } else {
        LauncherDimens.PORTRAIT_ROWS     // 6
    }

    val maxAppsPerPage = columns * rows

    // Resolve pages: use homePages if provided, otherwise chunk allApps
    val pages: List<List<HomeScreenItem>> = remember(homePages, allApps, maxAppsPerPage) {
        if (homePages != null && homePages.isNotEmpty()) {
            homePages.keys.sorted().map { homePages[it] ?: emptyList() }
        } else if (allApps.isNotEmpty()) {
            allApps.map { HomeScreenItem.AppItem(it) }.chunked(maxAppsPerPage)
        } else {
            listOf(emptyList())
        }
    }

    val homePageCount = pages.size
    val totalPagerCount = if (includeAppLibrary) homePageCount + 1 else homePageCount

    val pagerState = rememberPagerState(initialPage = 0) { totalPagerCount }

    // Synchronize horizontal swipe with Wallpaper parallax offset
    LaunchedEffect(pagerState, totalPagerCount) {
        snapshotFlow {
            val page = pagerState.currentPage
            val offset = pagerState.currentPageOffsetFraction
            if (totalPagerCount > 1) {
                val progress = (page + offset) / (totalPagerCount - 1).toFloat()
                (progress - 0.5f) * 1.4f
            } else {
                0f
            }
        }.collect { parallax ->
            WallpaperManager.setParallaxOffset(parallax)
        }
    }

    // Automatically exit Jiggle Mode when navigating to the App Library page
    LaunchedEffect(pagerState.currentPage, isJiggleMode) {
        if (includeAppLibrary && pagerState.currentPage == homePageCount && isJiggleMode) {
            onBackgroundClick?.invoke()
        }
    }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Main horizontal page swiper filling remaining vertical space
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (isJiggleMode) {
                        onBackgroundClick?.invoke()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                userScrollEnabled = !isJiggleMode // Lock swiping while dragging icons in Jiggle Mode
            ) { pageIndex ->
                if (includeAppLibrary && pageIndex == homePageCount) {
                    // Final page: iPadOS App Library
                    AppLibraryScreen(
                        allApps = allApps,
                        onAppClick = { app -> onAppClick(app, null) },
                        onAppLongClick = onAppLongClick
                    )
                } else {
                    // Standard Home Screen Page
                    val pageItems = pages.getOrElse(pageIndex) { emptyList() }
                    HomeScreenGridPage(
                        items = pageItems,
                        pageIndex = pageIndex,
                        isCurrentPage = (pagerState.currentPage == pageIndex),
                        columns = columns,
                        rows = rows,
                        isJiggleMode = isJiggleMode,
                        onAppClick = onAppClick,
                        onFolderClick = { folder -> onFolderClick?.invoke(folder) },
                        onWidgetClick = onWidgetClick,
                        onAppLongClick = onAppLongClick,
                        onFolderLongClick = onFolderLongClick,
                        onWidgetLongClick = onWidgetLongClick,
                        onDeleteApp = onDeleteApp,
                        onDeleteFolder = onDeleteFolder,
                        onDeleteWidget = onDeleteWidget,
                        onReorderItems = onReorderItems,
                        onCreateFolderFromDrop = onCreateFolderFromDrop,
                        onDragToEdge = { direction ->
                            coroutineScope.launch {
                                if (direction < 0 && pageIndex > 0) {
                                    pagerState.animateScrollToPage(pageIndex - 1)
                                } else if (direction > 0 && pageIndex < homePageCount - 1) {
                                    pagerState.animateScrollToPage(pageIndex + 1)
                                }
                            }
                        },
                        onTriggerSpotlight = onTriggerSpotlight,
                        onBackgroundClick = onBackgroundClick
                    )
                }
            }
        }

        // Bottom Page Indicator Dots above the dock
        PageIndicatorRow(
            pagerState = pagerState,
            homePageCount = homePageCount,
            hasAppLibrary = includeAppLibrary,
            onDotClick = { targetIndex ->
                coroutineScope.launch {
                    pagerState.animateScrollToPage(targetIndex)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )
    }
}

/**
 * Data model for background tap ripple animations.
 */
private data class TapRippleData(
    val id: Long,
    val center: Offset
)

/**
 * Subtle expanding translucent ripple circle that fades out over 450ms when tapping empty space.
 */
@Composable
private fun TapRipple(
    key: Long,
    center: Offset,
    onFinished: () -> Unit
) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(key) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing)
        )
        onFinished()
    }

    val density = LocalDensity.current
    val currentRadius = with(density) { 75.dp.toPx() } * progress.value
    val currentAlpha = (1f - progress.value) * 0.35f
    val strokeWidthPx = with(density) { 1.5.dp.toPx() }

    Canvas(modifier = Modifier.fillMaxSize()) {
        if (currentAlpha > 0f && currentRadius > 0f) {
            drawCircle(
                color = Color.White.copy(alpha = currentAlpha * 0.45f),
                radius = currentRadius,
                center = center
            )
            drawCircle(
                color = Color.White.copy(alpha = currentAlpha * 0.90f),
                radius = currentRadius,
                center = center,
                style = Stroke(width = strokeWidthPx)
            )
        }
    }
}

/**
 * Renders a single home screen page grid supporting multi-cell widgets alongside
 * app icons, folders, and drag-and-drop rearranging in Jiggle Mode.
 *
 * Micro-interactions & Spring animations:
 * - Staggered fade-in + slight upward slide for icons on page transitions (20ms delay per icon).
 * - Pull-to-search: rubber-band scale down (to 0.97) and proportional downward translation on swipe down.
 * - Orientation change: smooth 300ms position animation (animateDpAsState).
 * - Background tap ripple: subtle expanding circle when empty space is tapped.
 */
@Composable
private fun HomeScreenGridPage(
    items: List<HomeScreenItem>,
    pageIndex: Int,
    isCurrentPage: Boolean,
    columns: Int,
    rows: Int,
    isJiggleMode: Boolean,
    onAppClick: (AppInfo, Rect?) -> Unit,
    onFolderClick: (AppFolder) -> Unit,
    onWidgetClick: ((WidgetInfo) -> Unit)?,
    onAppLongClick: ((AppInfo) -> Unit)?,
    onFolderLongClick: ((AppFolder) -> Unit)?,
    onWidgetLongClick: ((WidgetInfo) -> Unit)?,
    onDeleteApp: ((AppInfo) -> Unit)?,
    onDeleteFolder: ((AppFolder) -> Unit)?,
    onDeleteWidget: ((WidgetInfo) -> Unit)?,
    onReorderItems: ((pageIndex: Int, fromIndex: Int, toIndex: Int) -> Unit)?,
    onCreateFolderFromDrop: ((sourceApp: AppInfo, targetApp: AppInfo) -> Unit)?,
    onDragToEdge: ((direction: Int) -> Unit)?,
    onTriggerSpotlight: (() -> Unit)? = null,
    onBackgroundClick: (() -> Unit)? = null
) {
    val placedItems = remember(items, columns, rows) {
        layoutGridPage(items, columns, rows)
    }

    val coroutineScope = rememberCoroutineScope()

    // Drag-and-drop state
    var draggingItemId by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var hoverTargetIndex by remember { mutableIntStateOf(-1) }
    var hoverStartTime by remember { mutableLongStateOf(0L) }

    // Background Tap Ripple state
    var ripples by remember { mutableStateOf(listOf<TapRippleData>()) }

    // Pull-to-search rubber-band animation state
    val pullOffsetAnim = remember { Animatable(0f) }
    val density = LocalDensity.current
    val maxPullPx = with(density) { 65.dp.toPx() }
    val pullTranslationY = (pullOffsetAnim.value * 0.35f).coerceIn(0f, maxPullPx)
    val pullProgress = if (maxPullPx > 0f) (pullTranslationY / maxPullPx).coerceIn(0f, 1f) else 0f
    val pullScale = (1.0f - (pullProgress * 0.03f)).coerceIn(0.97f, 1.0f)

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp, vertical = 8.dp)
            .pointerInput(isJiggleMode) {
                detectTapGestures { offset ->
                    if (isJiggleMode) {
                        onBackgroundClick?.invoke()
                    } else {
                        ripples = ripples + TapRippleData(id = System.nanoTime(), center = offset)
                    }
                }
            }
            .pointerInput(isJiggleMode) {
                if (!isJiggleMode) {
                    detectVerticalDragGestures(
                        onDragStart = {},
                        onDragEnd = {
                            val currentPull = pullOffsetAnim.value
                            if (currentPull > 120f) {
                                onTriggerSpotlight?.invoke()
                            }
                            coroutineScope.launch {
                                pullOffsetAnim.animateTo(
                                    targetValue = 0f,
                                    animationSpec = spring(
                                        dampingRatio = 0.55f,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                )
                            }
                        },
                        onDragCancel = {
                            coroutineScope.launch {
                                pullOffsetAnim.animateTo(
                                    targetValue = 0f,
                                    animationSpec = spring(
                                        dampingRatio = 0.55f,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                )
                            }
                        },
                        onVerticalDrag = { change, dragAmount ->
                            if (dragAmount > 0f || pullOffsetAnim.value > 0f) {
                                change.consume()
                                val newTarget = (pullOffsetAnim.value + dragAmount).coerceAtLeast(0f)
                                coroutineScope.launch {
                                    pullOffsetAnim.snapTo(newTarget)
                                }
                            }
                        }
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        // Render subtle expanding ripples on background taps
        ripples.forEach { ripple ->
            TapRipple(
                key = ripple.id,
                center = ripple.center,
                onFinished = {
                    ripples = ripples.filter { it.id != ripple.id }
                }
            )
        }

        val spacingX = 16.dp
        val spacingY = LauncherDimens.GridVerticalSpacing // 20.dp

        val totalSpacingX = spacingX * (columns - 1)
        val totalSpacingY = spacingY * (rows - 1)

        val cellWidth = ((maxWidth - totalSpacingX) / columns).coerceAtLeast(60.dp)
        val cellHeight = ((maxHeight - totalSpacingY) / rows).coerceAtLeast(70.dp)

        val gridWidth = cellWidth * columns + totalSpacingX
        val gridHeight = cellHeight * rows + totalSpacingY

        Box(
            modifier = Modifier
                .size(width = gridWidth, height = gridHeight)
                .graphicsLayer {
                    translationY = pullTranslationY
                    scaleX = pullScale
                    scaleY = pullScale
                }
        ) {
            if (placedItems.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    FrostedGlassBox(
                        modifier = Modifier.size(64.dp),
                        shape = CircleShape,
                        backgroundColor = Color.White.copy(alpha = 0.15f),
                        borderColor = FrostedGlassBorder,
                        borderWidth = 0.5.dp,
                        elevation = 8.dp,
                        shadowColor = IosShadowBlue
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Apps,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Applications Available",
                        fontFamily = InterFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Apps installed on your tablet will appear here.",
                        fontFamily = InterFontFamily,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                placedItems.forEachIndexed { itemIndex, placed ->
                val isBeingDragged = placed.item.id == draggingItemId
                val isHoverTarget = hoverTargetIndex == itemIndex && !isBeingDragged

                // Target item animation: slightly scales up when another icon hovers over it
                val hoverScale by animateFloatAsState(
                    targetValue = if (isHoverTarget) 1.12f else 1.0f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    ),
                    label = "hover_scale"
                )

                val itemWidth = cellWidth * placed.colSpan + spacingX * (placed.colSpan - 1)
                val itemHeight = cellHeight * placed.rowSpan + spacingY * (placed.rowSpan - 1)
                val itemLeft = (cellWidth + spacingX) * placed.col
                val itemTop = (cellHeight + spacingY) * placed.row

                // Smooth orientation change animations (300ms)
                val animatedLeft by animateDpAsState(
                    targetValue = itemLeft,
                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                    label = "grid_item_left_$itemIndex"
                )
                val animatedTop by animateDpAsState(
                    targetValue = itemTop,
                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                    label = "grid_item_top_$itemIndex"
                )
                val animatedWidth by animateDpAsState(
                    targetValue = itemWidth,
                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                    label = "grid_item_width_$itemIndex"
                )
                val animatedHeight by animateDpAsState(
                    targetValue = itemHeight,
                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                    label = "grid_item_height_$itemIndex"
                )

                // Staggered page transition animation: 20ms delay per icon, fade-in + slight upward slide
                val staggerProgress = remember { Animatable(if (isCurrentPage) 1f else 0f) }
                LaunchedEffect(isCurrentPage) {
                    if (isCurrentPage) {
                        staggerProgress.snapTo(0f)
                        delay((itemIndex * 20L).coerceAtMost(350L))
                        staggerProgress.animateTo(
                            targetValue = 1f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        )
                    } else {
                        staggerProgress.snapTo(0f)
                    }
                }

                // Out-of-sync jiggle seed
                val jiggleSeed = (placed.col * 13) + (placed.row * 7) + itemIndex

                Box(
                    modifier = Modifier
                        .offset(x = animatedLeft, y = animatedTop)
                        .size(width = animatedWidth, height = animatedHeight)
                        .zIndex(if (isBeingDragged) 25f else if (isHoverTarget) 15f else 1f)
                        .offset {
                            if (isBeingDragged) {
                                IntOffset(dragOffset.x.roundToInt(), dragOffset.y.roundToInt())
                            } else {
                                IntOffset.Zero
                            }
                        }
                        .scale(if (isBeingDragged) 1.08f else hoverScale)
                        .graphicsLayer {
                            alpha = staggerProgress.value
                            translationY = (1f - staggerProgress.value) * 30f
                        }
                        .pointerInput(isJiggleMode) {
                            if (!isJiggleMode) return@pointerInput
                            detectDragGesturesAfterLongPress(
                                onDragStart = {
                                    draggingItemId = placed.item.id
                                    dragOffset = Offset.Zero
                                    hoverTargetIndex = -1
                                    hoverStartTime = 0L
                                },
                                onDragEnd = {
                                    val currentDraggedId = draggingItemId
                                    val targetIdx = hoverTargetIndex
                                    val hoverDuration = System.currentTimeMillis() - hoverStartTime

                                    if (currentDraggedId != null && targetIdx in placedItems.indices && targetIdx != itemIndex) {
                                        val targetPlaced = placedItems[targetIdx]
                                        // If hovering over another app for >= 500ms, create folder!
                                        if (placed.item is HomeScreenItem.AppItem &&
                                            targetPlaced.item is HomeScreenItem.AppItem &&
                                            hoverDuration >= 450L
                                        ) {
                                            onCreateFolderFromDrop?.invoke(
                                                placed.item.app,
                                                targetPlaced.item.app
                                            )
                                        } else {
                                            // Reorder slots
                                            onReorderItems?.invoke(pageIndex, itemIndex, targetIdx)
                                        }
                                    }

                                    draggingItemId = null
                                    dragOffset = Offset.Zero
                                    hoverTargetIndex = -1
                                    hoverStartTime = 0L
                                },
                                onDragCancel = {
                                    draggingItemId = null
                                    dragOffset = Offset.Zero
                                    hoverTargetIndex = -1
                                    hoverStartTime = 0L
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    dragOffset += dragAmount

                                    // Check screen edge drag
                                    val absoluteCenterX = animatedLeft.toPx() + animatedWidth.toPx() / 2f + dragOffset.x
                                    if (absoluteCenterX < 32.dp.toPx()) {
                                        onDragToEdge?.invoke(-1)
                                    } else if (absoluteCenterX > gridWidth.toPx() - 32.dp.toPx()) {
                                        onDragToEdge?.invoke(1)
                                    }

                                    // Detect which item is being hovered over
                                    val currentCenterX = animatedLeft.toPx() + animatedWidth.toPx() / 2f + dragOffset.x
                                    val currentCenterY = animatedTop.toPx() + animatedHeight.toPx() / 2f + dragOffset.y

                                    var matchedIdx = -1
                                    for ((idx, other) in placedItems.withIndex()) {
                                        if (idx == itemIndex) continue
                                        val otherLeft = (cellWidth + spacingX).toPx() * other.col
                                        val otherTop = (cellHeight + spacingY).toPx() * other.row
                                        val otherW = (cellWidth * other.colSpan + spacingX * (other.colSpan - 1)).toPx()
                                        val otherH = (cellHeight * other.rowSpan + spacingY * (other.rowSpan - 1)).toPx()

                                        if (currentCenterX >= otherLeft && currentCenterX <= otherLeft + otherW &&
                                            currentCenterY >= otherTop && currentCenterY <= otherTop + otherH
                                        ) {
                                            matchedIdx = idx
                                            break
                                        }
                                    }

                                    if (matchedIdx != hoverTargetIndex) {
                                        hoverTargetIndex = matchedIdx
                                        hoverStartTime = System.currentTimeMillis()
                                    }
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    when (val item = placed.item) {
                        is HomeScreenItem.AppItem -> {
                            AppIconItem(
                                app = item.app,
                                onClick = {
                                    if (!isJiggleMode) {
                                        onAppClick(item.app, null)
                                    }
                                },
                                onClickWithBounds = { app, bounds ->
                                    if (!isJiggleMode) {
                                        onAppClick(app, bounds)
                                    }
                                },
                                onLongClick = onAppLongClick?.let { { it(item.app) } },
                                isJiggleMode = isJiggleMode,
                                seed = jiggleSeed,
                                onDeleteClick = onDeleteApp?.let { { it(item.app) } }
                            )
                        }
                        is HomeScreenItem.FolderItem -> {
                            FolderIcon(
                                folder = item.folder,
                                onClick = {
                                    if (!isJiggleMode) {
                                        onFolderClick(item.folder)
                                    }
                                },
                                onLongClick = onFolderLongClick?.let { { it(item.folder) } },
                                isJiggleMode = isJiggleMode,
                                seed = jiggleSeed,
                                onDeleteClick = onDeleteFolder?.let { { it(item.folder) } }
                            )
                        }
                        is HomeScreenItem.WidgetItem -> {
                            LauncherWidget(
                                widget = item.widget,
                                onClick = {
                                    if (!isJiggleMode) {
                                        onWidgetClick?.invoke(item.widget)
                                    }
                                },
                                onLongClick = onWidgetLongClick?.let { { it(item.widget) } },
                                isJiggleMode = isJiggleMode,
                                seed = jiggleSeed,
                                onDeleteClick = onDeleteWidget?.let { { it(item.widget) } },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(4.dp)
                            ) {
                                WidgetContent(widget = item.widget)
                            }
                        }
                    }
                }
            }
        }
    }
    }
}

/**
 * Page indicator dots at the bottom of the content area.
 * - Smooth size (6dp -> 8dp) & opacity (0.4f -> 1.0f) animation when page changes
 * - Active dot: 100% white with animated radial glow
 * - Inactive dots: 40% white
 * - Right-most dot: 2x2 grid representing iPadOS App Library with smooth opacity transition
 */
@Composable
private fun PageIndicatorRow(
    pagerState: PagerState,
    homePageCount: Int,
    hasAppLibrary: Boolean,
    onDotClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Standard home screen page dots
        repeat(homePageCount) { index ->
            val isCurrent = pagerState.currentPage == index

            val dotSize by animateDpAsState(
                targetValue = if (isCurrent) 8.dp else 6.dp,
                animationSpec = spring(
                    dampingRatio = 0.6f,
                    stiffness = Spring.StiffnessMedium
                ),
                label = "dot_size_$index"
            )
            val dotAlpha by animateFloatAsState(
                targetValue = if (isCurrent) 1.0f else 0.40f,
                animationSpec = tween(durationMillis = 250),
                label = "dot_alpha_$index"
            )
            val glowAlpha by animateFloatAsState(
                targetValue = if (isCurrent) 0.55f else 0.0f,
                animationSpec = tween(durationMillis = 250),
                label = "dot_glow_$index"
            )

            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onDotClick(index) },
                contentAlignment = Alignment.Center
            ) {
                // Smooth animated glow on active dot
                if (glowAlpha > 0f) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = glowAlpha),
                                        Color.Transparent
                                    )
                                ),
                                shape = CircleShape
                            )
                    )
                }

                // Smoothly animated circle dot
                Box(
                    modifier = Modifier
                        .size(dotSize)
                        .background(
                            color = Color.White.copy(alpha = dotAlpha),
                            shape = CircleShape
                        )
                )
            }
        }

        // App Library indicator dot (2x2 grid of 4 tiny dots forming a square)
        if (hasAppLibrary) {
            val isAppLibraryActive = pagerState.currentPage == homePageCount
            val appLibraryAlpha by animateFloatAsState(
                targetValue = if (isAppLibraryActive) 1.0f else 0.40f,
                animationSpec = tween(durationMillis = 250),
                label = "app_lib_alpha"
            )
            val appLibraryGlowAlpha by animateFloatAsState(
                targetValue = if (isAppLibraryActive) 0.55f else 0.0f,
                animationSpec = tween(durationMillis = 250),
                label = "app_lib_glow"
            )

            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onDotClick(homePageCount) },
                contentAlignment = Alignment.Center
            ) {
                // Glow on active App Library dot
                if (appLibraryGlowAlpha > 0f) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = appLibraryGlowAlpha),
                                        Color.Transparent
                                    )
                                ),
                                shape = CircleShape
                            )
                    )
                }

                // 2x2 grid of 4 dots forming a square
                Column(
                    modifier = Modifier.size(7.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(modifier = Modifier.size(2.5.dp).background(Color.White.copy(alpha = appLibraryAlpha), CircleShape))
                        Box(modifier = Modifier.size(2.5.dp).background(Color.White.copy(alpha = appLibraryAlpha), CircleShape))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(modifier = Modifier.size(2.5.dp).background(Color.White.copy(alpha = appLibraryAlpha), CircleShape))
                        Box(modifier = Modifier.size(2.5.dp).background(Color.White.copy(alpha = appLibraryAlpha), CircleShape))
                    }
                }
            }
        }
    }
}
