package com.tabletlauncher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.data.model.WidgetInfo
import com.tabletlauncher.data.model.WidgetSize
import com.tabletlauncher.data.model.WidgetType
import com.tabletlauncher.ui.theme.FrostedGlassBackground
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.theme.IosBlue
import com.tabletlauncher.ui.theme.IosShadowBlue
import com.tabletlauncher.ui.theme.IosSurfaceDark
import com.tabletlauncher.ui.theme.TextSecondary
import com.tabletlauncher.ui.theme.TextTertiary
import com.tabletlauncher.ui.widgets.BatteryWidget
import com.tabletlauncher.ui.widgets.ClockWidget
import com.tabletlauncher.ui.widgets.CalendarWidget
import com.tabletlauncher.ui.widgets.WeatherWidget

private val SheetShape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
private val WidgetPreviewCardShape = RoundedCornerShape(16.dp)

data class GalleryWidgetItem(
    val type: WidgetType,
    val title: String,
    val size: WidgetSize,
    val description: String
)

private val AvailableWidgets = listOf(
    GalleryWidgetItem(
        type = WidgetType.Weather,
        title = "Weather",
        size = WidgetSize.Medium,
        description = "Current temperature and 5-day forecast."
    ),
    GalleryWidgetItem(
        type = WidgetType.Calendar,
        title = "Calendar",
        size = WidgetSize.Medium,
        description = "Today's date and upcoming scheduled events."
    ),
    GalleryWidgetItem(
        type = WidgetType.Clock,
        title = "Clock",
        size = WidgetSize.Small,
        description = "World clock with live ticking analog second hand."
    ),
    GalleryWidgetItem(
        type = WidgetType.Battery,
        title = "Battery",
        size = WidgetSize.Small,
        description = "Live device battery level and charging status."
    )
)

/**
 * iPadOS-style Widget Gallery overlay opened from the top-left "+" button in Jiggle Mode.
 */
@Composable
fun WidgetGallerySheet(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onAddWidget: (WidgetType) -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(tween(200)),
        exit = fadeOut(tween(180)),
        modifier = modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.50f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    onDismiss()
                },
            contentAlignment = Alignment.BottomCenter
        ) {
            FrostedGlassBox(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .height(580.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        // Prevent dismissal when clicking inside sheet
                    }
                    .padding(24.dp),
                shape = SheetShape,
                backgroundColor = IosSurfaceDark.copy(alpha = 0.90f),
                borderColor = FrostedGlassBorder,
                borderWidth = 0.5.dp,
                elevation = 12.dp,
                shadowColor = IosShadowBlue
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Widget Gallery",
                                fontFamily = InterFontFamily,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.SemiBold, // Settings header: weight 600 (SemiBold)
                                color = Color.White
                            )
                            Text(
                                text = "Tap a widget to add it to your home screen",
                                fontFamily = InterFontFamily,
                                fontSize = 13.sp,
                                color = TextSecondary
                            )
                        }

                        // Close button (8dp corner radius)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                            .clickable { onDismiss() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Scrollable list of widgets
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        items(AvailableWidgets, key = { it.type.name }) { item ->
                            WidgetGalleryCard(
                                item = item,
                                onAdd = {
                                    onAddWidget(item.type)
                                    onDismiss()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Preview card inside the Widget Gallery.
 */
@Composable
private fun WidgetGalleryCard(
    item: GalleryWidgetItem,
    onAdd: () -> Unit
) {
    FrostedGlassBox(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onAdd() }
            .padding(16.dp),
        shape = WidgetPreviewCardShape,
        backgroundColor = FrostedGlassBackground,
        borderColor = FrostedGlassBorder,
        borderWidth = 0.5.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Title, Description, and Size badge
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.title,
                        fontFamily = InterFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.White.copy(alpha = 0.18f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${item.size.name} (${item.size.colSpan}x${item.size.rowSpan})",
                            fontFamily = InterFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.90f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = item.description,
                    fontFamily = InterFontFamily,
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                // "+ Add Widget" Button: 8dp corner radius, iOS blue (#007AFF)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(IosBlue)
                        .clickable { onAdd() }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Add Widget",
                            fontFamily = InterFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right: Widget Live Preview Container
            Box(
                modifier = Modifier
                    .size(
                        width = if (item.size == WidgetSize.Medium) 200.dp else 120.dp,
                        height = 110.dp
                    )
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.12f))
                    .border(
                        BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                        RoundedCornerShape(16.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (item.type) {
                    WidgetType.Weather -> WeatherWidget()
                    WidgetType.Calendar -> CalendarWidget()
                    WidgetType.Clock -> ClockWidget()
                    WidgetType.Battery -> BatteryWidget()
                }
            }
        }
    }
}
