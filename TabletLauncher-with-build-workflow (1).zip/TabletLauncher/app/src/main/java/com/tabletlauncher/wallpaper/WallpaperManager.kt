package com.tabletlauncher.wallpaper

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Represents the state of the active wallpaper.
 */
sealed interface WallpaperState {
    /**
     * The default iPadOS dark gradient aesthetic.
     */
    data object Default : WallpaperState

    /**
     * A user-selected custom bitmap wallpaper.
     */
    data class Custom(val bitmap: Bitmap) : WallpaperState
}

/**
 * Singleton manager that holds the active wallpaper state and parallax offset.
 */
object WallpaperManager {
    /**
     * Observable state for the current wallpaper. Recomposes UI automatically upon modification.
     */
    var currentWallpaper by mutableStateOf<WallpaperState>(WallpaperState.Default)
        private set

    /**
     * Parallax offset fraction between -1.0f (swiped right) and 1.0f (swiped left).
     */
    var parallaxOffset by mutableFloatStateOf(0f)
        private set

    /**
     * Dark/Light mode theme state for the wallpaper.
     */
    var isDarkMode by mutableStateOf(true)
        private set

    /**
     * Toggles between dark and light wallpaper aesthetics.
     */
    fun toggleDarkMode() {
        isDarkMode = !isDarkMode
    }

    fun setDarkMode(dark: Boolean) {
        isDarkMode = dark
    }

    /**
     * Sets a custom wallpaper from a [Bitmap].
     */
    fun setCustomWallpaper(bitmap: Bitmap) {
        currentWallpaper = WallpaperState.Custom(bitmap)
    }

    /**
     * Resets the wallpaper back to the iPadOS-style default gradient.
     */
    fun resetToDefault() {
        currentWallpaper = WallpaperState.Default
    }

    /**
     * Updates the horizontal parallax offset fraction (typically driven by page swiping).
     */
    fun setParallaxOffset(offset: Float) {
        parallaxOffset = offset.coerceIn(-1f, 1f)
    }
}
