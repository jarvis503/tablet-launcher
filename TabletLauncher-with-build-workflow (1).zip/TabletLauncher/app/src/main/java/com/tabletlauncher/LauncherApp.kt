package com.tabletlauncher

import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.data.model.WidgetType
import com.tabletlauncher.ui.animation.AppLaunchOverlay
import com.tabletlauncher.ui.animation.AppLaunchState
import com.tabletlauncher.ui.animation.EaseInOut
import com.tabletlauncher.ui.components.ControlCenter
import com.tabletlauncher.ui.components.FolderOpenView
import com.tabletlauncher.ui.components.HomeScreenPager
import com.tabletlauncher.ui.components.IpadDock
import com.tabletlauncher.ui.components.IpadStatusBar
import com.tabletlauncher.ui.components.NotificationCenter
import com.tabletlauncher.ui.components.RemoveAppDialog
import com.tabletlauncher.ui.components.SpotlightSearch
import com.tabletlauncher.ui.components.WidgetGallerySheet
import com.tabletlauncher.ui.layout.LauncherScaffold
import com.tabletlauncher.ui.layout.LocalScreenDimensions
import com.tabletlauncher.ui.theme.InterFontFamily
import com.tabletlauncher.ui.viewmodel.LauncherViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Root composable for TabletLauncher:
 * - [com.tabletlauncher.wallpaper.WallpaperBackground] (lowest layer behind all content)
 * - [IpadStatusBar] (top-left swipe down -> Notification Center, top-right swipe down -> Control Center)
 * - [HomeScreenPager] (5x6 portrait / 7x4 landscape grid with horizontal swipe, dots, folders, widgets, and App Library)
 * - [IpadDock] (floating glassmorphism dock pre-populated with common apps)
 * - [FolderOpenView] (expanding frosted glass overlay when an app folder is tapped)
 * - [NotificationCenter] (top-left swipe-down overlay)
 * - [ControlCenter] (top-right swipe-down floating panel with connectivity, sliders, and toggles)
 * - Jiggle Mode: continuous subtle rotation, top-left "+" widget gallery button, top-right "Done" button,
 *   drag-and-drop rearranging, folder creation on drop, and delete badges.
 * - Smooth iPadOS App Launch Animation: expands from icon bounds into full-screen white overlay with EaseInOut.
 * - Return Animation onResume: 200ms subtle fade-in and 0.95 -> 1.0 scale.
 */
@Composable
fun LauncherApp(
    viewModel: LauncherViewModel = viewModel()
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val density = LocalDensity.current
    val screenDimensions = LocalScreenDimensions.current
    val configuration = LocalConfiguration.current

    val screenWidth = if (screenDimensions.width > 0.dp) screenDimensions.width else configuration.screenWidthDp.dp
    val screenHeight = if (screenDimensions.height > 0.dp) screenDimensions.height else configuration.screenHeightDp.dp
    val screenWidthPx = with(density) { screenWidth.toPx() }
    val screenHeightPx = with(density) { screenHeight.toPx() }

    val allApps by viewModel.allApps.collectAsStateWithLifecycle()
    val dockApps by viewModel.dockApps.collectAsStateWithLifecycle()
    val homeScreenPages by viewModel.homeScreenPages.collectAsStateWithLifecycle()
    val openedFolder by viewModel.openedFolder.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val isNotificationCenterOpen by viewModel.isNotificationCenterOpen.collectAsStateWithLifecycle()
    val isSpotlightOpen by viewModel.isSpotlightOpen.collectAsStateWithLifecycle()
    val isControlCenterOpen by viewModel.isControlCenterOpen.collectAsStateWithLifecycle()

    // Jiggle Mode state flows
    val isJiggleMode by viewModel.isJiggleMode.collectAsStateWithLifecycle()
    val isWidgetGalleryOpen by viewModel.isWidgetGalleryOpen.collectAsStateWithLifecycle()
    val appPendingRemoval by viewModel.appPendingRemoval.collectAsStateWithLifecycle()

    // Control Center state flows
    val isAirplaneMode by viewModel.isAirplaneMode.collectAsStateWithLifecycle()
    val isWifiEnabled by viewModel.isWifiEnabled.collectAsStateWithLifecycle()
    val isBluetoothEnabled by viewModel.isBluetoothEnabled.collectAsStateWithLifecycle()
    val isAirDropEnabled by viewModel.isAirDropEnabled.collectAsStateWithLifecycle()
    val isRotationLocked by viewModel.isRotationLocked.collectAsStateWithLifecycle()
    val isDoNotDisturb by viewModel.isDoNotDisturb.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val isScreenMirroring by viewModel.isScreenMirroring.collectAsStateWithLifecycle()
    val brightness by viewModel.brightness.collectAsStateWithLifecycle()
    val volume by viewModel.volume.collectAsStateWithLifecycle()

    // Launch Animation States
    var launchState by remember { mutableStateOf<AppLaunchState?>(null) }
    val launchProgress = remember { Animatable(0f) }

    // Return Animation States (onResume)
    val returnAlpha = remember { Animatable(1f) }
    val returnScale = remember { Animatable(1f) }
    var hasLaunchedApp by remember { mutableStateOf(false) }

    // Lifecycle observer to trigger RETURN animation when user returns to launcher
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                // Clear any leftover launch overlay
                launchState = null
                coroutineScope.launch {
                    launchProgress.snapTo(0f)
                }

                if (hasLaunchedApp) {
                    // Subtle 200ms fade-in and 0.95 -> 1.0 scale animation on return
                    coroutineScope.launch {
                        returnAlpha.snapTo(0f)
                        returnScale.snapTo(0.95f)

                        launch {
                            returnAlpha.animateTo(
                                targetValue = 1f,
                                animationSpec = tween(durationMillis = 200, easing = LinearEasing)
                            )
                        }
                        launch {
                            returnScale.animateTo(
                                targetValue = 1f,
                                animationSpec = tween(durationMillis = 250, easing = EaseInOut)
                            )
                        }
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    /**
     * Executes the smooth iPadOS app launch sequence:
     * 1. Captures icon bounds on screen.
     * 2. Expands white overlay rectangle from icon bounds to full screen with EaseInOut curve (~400ms).
     * 3. Scales tapped icon up and cross-fades into white screen.
     * 4. Fades out other launcher elements.
     * 5. Launches app via Intent upon completion.
     */
    fun triggerAppLaunch(app: AppInfo, bounds: Rect?) {
        hasLaunchedApp = true
        coroutineScope.launch {
            val sourceBounds = if (bounds != null && !bounds.isEmpty) {
                bounds
            } else {
                // Fallback to center of screen if bounds unavailable
                val halfW = with(density) { 30.dp.toPx() }
                val halfH = with(density) { 30.dp.toPx() }
                Rect(
                    screenWidthPx / 2f - halfW,
                    screenHeightPx / 2f - halfH,
                    screenWidthPx / 2f + halfW,
                    screenHeightPx / 2f + halfH
                )
            }

            launchState = AppLaunchState(app, sourceBounds)
            launchProgress.snapTo(0f)

            // Smooth 400ms EaseInOut expansion animation
            launchProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 400, easing = EaseInOut)
            )

            // Launch the target application after expansion finishes
            viewModel.launchApp(context, app.packageName)

            // Graceful hold so white overlay covers transition until app activity surfaces
            delay(150)
            launchState = null
            launchProgress.snapTo(0f)
        }
    }

    // Alpha for all other launcher elements: smoothly fades out during expansion animation
    val launcherFadeAlpha = if (launchState != null) {
        (1f - launchProgress.value * 2.0f).coerceIn(0f, 1f)
    } else {
        1f
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Base Launcher Scaffold wrapped with launch fade-out and return animations
        LauncherScaffold(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = launcherFadeAlpha * returnAlpha.value
                    scaleX = returnScale.value
                    scaleY = returnScale.value
                },
            statusBar = {
                if (isJiggleMode) {
                    // Top Jiggle Mode Controls Bar (replaces status bar in edit mode)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 24.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Top-Left "+" Add Widget Button
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .shadow(8.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                                .border(
                                    BorderStroke(0.5.dp, Color.White.copy(alpha = 0.10f)),
                                    CircleShape
                                )
                                .clickable {
                                    viewModel.openWidgetGallery()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = "Add Widget",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Top-Right "Done" Pill Button: half of 34dp height = 17dp
                        Box(
                            modifier = Modifier
                                .height(34.dp)
                                .shadow(8.dp, RoundedCornerShape(17.dp))
                                .clip(RoundedCornerShape(17.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .border(
                                    BorderStroke(0.5.dp, Color.White.copy(alpha = 0.10f)),
                                    RoundedCornerShape(17.dp)
                                )
                                .clickable {
                                    viewModel.exitJiggleMode()
                                }
                                .padding(horizontal = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Done",
                                fontFamily = InterFontFamily,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                    }
                } else {
                    IpadStatusBar(
                        onSwipeDownTopLeft = {
                            viewModel.openNotificationCenter()
                        },
                        onSwipeDownTopRight = {
                            viewModel.openControlCenter()
                        }
                    )
                }
            },
            content = {
                if (isLoading && allApps.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(40.dp),
                            strokeWidth = 3.dp
                        )
                    }
                } else {
                    HomeScreenPager(
                        allApps = allApps,
                        homePages = homeScreenPages,
                        isJiggleMode = isJiggleMode,
                        onAppClick = { app, bounds ->
                            triggerAppLaunch(app, bounds)
                        },
                        onFolderClick = { folder ->
                            viewModel.openFolder(folder)
                        },
                        onWidgetClick = { widget ->
                            when (widget.type) {
                                WidgetType.Clock -> Toast.makeText(context, "Clock: Cupertino", Toast.LENGTH_SHORT).show()
                                WidgetType.Weather -> Toast.makeText(context, "Weather: 72° Sunny in Cupertino", Toast.LENGTH_SHORT).show()
                                WidgetType.Calendar -> Toast.makeText(context, "Calendar: 3 events scheduled today", Toast.LENGTH_SHORT).show()
                                WidgetType.Battery -> Toast.makeText(context, "Battery: Healthy", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onAppLongClick = {
                            viewModel.enterJiggleMode(context)
                        },
                        onFolderLongClick = {
                            viewModel.enterJiggleMode(context)
                        },
                        onWidgetLongClick = {
                            viewModel.enterJiggleMode(context)
                        },
                        onDeleteApp = { app ->
                            viewModel.requestRemoveApp(app)
                        },
                        onDeleteFolder = { folder ->
                            Toast.makeText(context, "Folder \"${folder.name}\" deleted", Toast.LENGTH_SHORT).show()
                        },
                        onDeleteWidget = { widget ->
                            viewModel.removeWidget(widget.id)
                            Toast.makeText(context, "Removed ${widget.title} widget", Toast.LENGTH_SHORT).show()
                        },
                        onReorderItems = { pageIdx, fromIdx, toIdx ->
                            viewModel.reorderPageItems(pageIdx, fromIdx, toIdx)
                        },
                        onCreateFolderFromDrop = { sourceApp, targetApp ->
                            viewModel.createFolderFromDrop(sourceApp, targetApp)
                            Toast.makeText(context, "Created folder with ${sourceApp.label} and ${targetApp.label}", Toast.LENGTH_SHORT).show()
                        },
                        onTriggerSpotlight = {
                            viewModel.openSpotlight()
                        },
                        onBackgroundClick = {
                            viewModel.exitJiggleMode()
                        }
                    )
                }
            },
            dock = {
                IpadDock(
                    dockApps = dockApps,
                    isJiggleMode = isJiggleMode,
                    onAppClick = { app, bounds ->
                        triggerAppLaunch(app, bounds)
                    },
                    onAppLongClick = {
                        viewModel.enterJiggleMode(context)
                    },
                    onRemoveDockApp = { app ->
                        viewModel.removeFromDock(app)
                        Toast.makeText(context, "Removed \"${app.label}\" from Dock", Toast.LENGTH_SHORT).show()
                    },
                    onReorderDockApps = { fromIdx, toIdx ->
                        viewModel.reorderDockApps(fromIdx, toIdx)
                    }
                )
            }
        )

        // iPadOS App Folder Open View Overlay (displays when an app folder is tapped)
        FolderOpenView(
            folder = openedFolder,
            onDismiss = {
                viewModel.closeFolder()
            },
            onAppClick = { app, bounds ->
                viewModel.closeFolder()
                triggerAppLaunch(app, bounds)
            },
            onRenameFolder = { newName ->
                openedFolder?.let { folder ->
                    viewModel.renameFolder(folder.id, newName)
                }
            }
        )

        // Remove from Home Screen Confirmation Dialog
        RemoveAppDialog(
            app = appPendingRemoval,
            onConfirm = { app ->
                viewModel.confirmRemoveApp(app)
                Toast.makeText(context, "Removed \"${app.label}\" from Home Screen", Toast.LENGTH_SHORT).show()
            },
            onDismiss = {
                viewModel.cancelRemoveApp()
            }
        )

        // iPadOS Widget Gallery Sheet Overlay
        WidgetGallerySheet(
            isOpen = isWidgetGalleryOpen,
            onDismiss = {
                viewModel.closeWidgetGallery()
            },
            onAddWidget = { widgetType ->
                viewModel.addWidgetToPage(0, widgetType)
                Toast.makeText(context, "Added ${widgetType.name} widget to Home Screen", Toast.LENGTH_SHORT).show()
            }
        )

        // iPadOS Notification Center Overlay (triggered from top-left swipe down)
        NotificationCenter(
            isOpen = isNotificationCenterOpen,
            onDismiss = {
                viewModel.closeNotificationCenter()
            }
        )

        // iPadOS Spotlight Search Overlay (triggered by pull-down on home screen)
        SpotlightSearch(
            isOpen = isSpotlightOpen,
            allApps = allApps,
            onDismiss = {
                viewModel.closeSpotlight()
            },
            onAppClick = { app, bounds ->
                triggerAppLaunch(app, bounds)
            }
        )

        // iPadOS Control Center Overlay (triggered from top-right swipe down)
        ControlCenter(
            isOpen = isControlCenterOpen,
            onDismiss = {
                viewModel.closeControlCenter()
            },
            isAirplaneMode = isAirplaneMode,
            isWifiEnabled = isWifiEnabled,
            isBluetoothEnabled = isBluetoothEnabled,
            isAirDropEnabled = isAirDropEnabled,
            isRotationLocked = isRotationLocked,
            isDoNotDisturb = isDoNotDisturb,
            isDarkMode = isDarkMode,
            isScreenMirroring = isScreenMirroring,
            brightness = brightness,
            volume = volume,
            onToggleAirplaneMode = { viewModel.toggleAirplaneMode() },
            onToggleWifi = { viewModel.toggleWifi() },
            onToggleBluetooth = { viewModel.toggleBluetooth() },
            onToggleAirDrop = { viewModel.toggleAirDrop() },
            onToggleRotationLock = { viewModel.toggleRotationLock() },
            onToggleDoNotDisturb = { viewModel.toggleDoNotDisturb() },
            onToggleDarkMode = { viewModel.toggleDarkMode() },
            onToggleScreenMirroring = { viewModel.toggleScreenMirroring() },
            onBrightnessChange = { viewModel.setBrightness(it) },
            onVolumeChange = { viewModel.setVolume(it) }
        )

        // iPadOS App Launch Fullscreen Expanding Animation Overlay
        AppLaunchOverlay(
            launchState = launchState,
            progress = launchProgress.value,
            screenWidthPx = screenWidthPx,
            screenHeightPx = screenHeightPx
        )
    }
}
