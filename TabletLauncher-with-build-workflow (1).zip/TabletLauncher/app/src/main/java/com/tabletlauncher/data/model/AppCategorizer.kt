package com.tabletlauncher.data.model

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build

/**
 * Categorization engine that automatically classifies installed apps into iPadOS-style categories.
 */
object AppCategorizer {

    val CATEGORIES = listOf(
        "Social",
        "Entertainment",
        "Productivity",
        "Utilities",
        "Games",
        "Education",
        "Shopping",
        "Other"
    )

    /**
     * Determines the category for an app by querying [ApplicationInfo.category] or analyzing package heuristics.
     */
    fun categorize(app: AppInfo, context: Context?): String {
        val pkg = app.packageName.lowercase()
        val label = app.label.lowercase()

        // 1. Query Android OS ApplicationInfo.category if available (API 26+)
        if (context != null) {
            try {
                val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    context.packageManager.getApplicationInfo(
                        app.packageName,
                        PackageManager.ApplicationInfoFlags.of(0L)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    context.packageManager.getApplicationInfo(app.packageName, 0)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    when (appInfo.category) {
                        ApplicationInfo.CATEGORY_GAME -> return "Games"
                        ApplicationInfo.CATEGORY_AUDIO,
                        ApplicationInfo.CATEGORY_VIDEO,
                        ApplicationInfo.CATEGORY_IMAGE -> return "Entertainment"
                        ApplicationInfo.CATEGORY_SOCIAL,
                        ApplicationInfo.CATEGORY_NEWS -> return "Social"
                        ApplicationInfo.CATEGORY_PRODUCTIVITY -> return "Productivity"
                        ApplicationInfo.CATEGORY_MAPS,
                        ApplicationInfo.CATEGORY_ACCESSIBILITY -> return "Utilities"
                    }
                }

                if ((appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0) {
                    return "Games"
                }
            } catch (_: Exception) {
                // Fallback to heuristic checks
            }
        }

        // 2. Package Name & Display Label Heuristics

        // Games
        if (pkg.contains("game") || label.contains("game") || pkg.contains("play") ||
            pkg.contains("arcade") || pkg.contains("puzzle") || pkg.contains("supercell") ||
            pkg.contains("roblox") || pkg.contains("minecraft") || pkg.contains("unity")) {
            return "Games"
        }

        // Social
        if (pkg.contains("facebook") || pkg.contains("instagram") || pkg.contains("twitter") ||
            pkg.contains("x.android") || pkg.contains("snapchat") || pkg.contains("whatsapp") ||
            pkg.contains("telegram") || pkg.contains("discord") || pkg.contains("reddit") ||
            pkg.contains("linkedin") || pkg.contains("tiktok") || pkg.contains("skype") ||
            pkg.contains("messenger") || pkg.contains("messaging") || pkg.contains("talk") ||
            pkg.contains("viber") || pkg.contains("mms") || label.contains("message") ||
            label.contains("chat") || label.contains("social")) {
            return "Social"
        }

        // Entertainment
        if (pkg.contains("youtube") || pkg.contains("netflix") || pkg.contains("spotify") ||
            pkg.contains("primevideo") || pkg.contains("disney") || pkg.contains("twitch") ||
            pkg.contains("hulu") || pkg.contains("music") || pkg.contains("video") ||
            pkg.contains("gallery") || pkg.contains("photos") || pkg.contains("camera") ||
            pkg.contains("podcast") || pkg.contains("sound") || pkg.contains("radio") ||
            label.contains("youtube") || label.contains("music") || label.contains("video") ||
            label.contains("photo") || label.contains("camera") || label.contains("gallery") ||
            label.contains("tv") || label.contains("movie")) {
            return "Entertainment"
        }

        // Productivity
        if (pkg.contains("mail") || pkg.contains("gm") || pkg.contains("outlook") ||
            pkg.contains("docs") || pkg.contains("sheets") || pkg.contains("slides") ||
            pkg.contains("office") || pkg.contains("word") || pkg.contains("excel") ||
            pkg.contains("powerpoint") || pkg.contains("calendar") || pkg.contains("keep") ||
            pkg.contains("notion") || pkg.contains("evernote") || pkg.contains("slack") ||
            pkg.contains("trello") || pkg.contains("zoom") || pkg.contains("teams") ||
            pkg.contains("meet") || label.contains("mail") || label.contains("note") ||
            label.contains("calendar") || label.contains("doc") || label.contains("pdf") ||
            label.contains("task")) {
            return "Productivity"
        }

        // Education
        if (pkg.contains("duolingo") || pkg.contains("khan") || pkg.contains("coursera") ||
            pkg.contains("udemy") || pkg.contains("quizlet") || pkg.contains("wikipedia") ||
            pkg.contains("study") || pkg.contains("learn") || pkg.contains("edu") ||
            pkg.contains("dictionary") || label.contains("learn") || label.contains("study") ||
            label.contains("school") || label.contains("dictionary")) {
            return "Education"
        }

        // Shopping
        if (pkg.contains("amazon") || pkg.contains("ebay") || pkg.contains("walmart") ||
            pkg.contains("target") || pkg.contains("aliexpress") || pkg.contains("etsy") ||
            pkg.contains("shein") || pkg.contains("shopify") || pkg.contains("temu") ||
            pkg.contains("flipkart") || pkg.contains("paypal") || pkg.contains("wallet") ||
            pkg.contains("pay") || label.contains("shop") || label.contains("store") ||
            label.contains("cart") || label.contains("buy")) {
            return "Shopping"
        }

        // Utilities
        if (pkg.contains("settings") || pkg.contains("calc") || pkg.contains("clock") ||
            pkg.contains("dialer") || pkg.contains("phone") || pkg.contains("contacts") ||
            pkg.contains("maps") || pkg.contains("browser") || pkg.contains("chrome") ||
            pkg.contains("firefox") || pkg.contains("files") || pkg.contains("documentsui") ||
            pkg.contains("filemanager") || pkg.contains("weather") || pkg.contains("tool") ||
            label.contains("setting") || label.contains("clock") || label.contains("calc") ||
            label.contains("file") || label.contains("phone") || label.contains("browser") ||
            label.contains("map")) {
            return "Utilities"
        }

        return "Other"
    }

    /**
     * Groups apps into ordered category buckets, returning only populated categories.
     */
    fun groupApps(apps: List<AppInfo>, context: Context?): Map<String, List<AppInfo>> {
        val grouped = mutableMapOf<String, MutableList<AppInfo>>()
        for (app in apps) {
            val category = categorize(app, context)
            grouped.getOrPut(category) { mutableListOf() }.add(app)
        }

        val result = linkedMapOf<String, List<AppInfo>>()
        for (category in CATEGORIES) {
            val list = grouped[category]
            if (!list.isNullOrEmpty()) {
                result[category] = list.sortedBy { it.label.lowercase() }
            }
        }
        return result
    }
}
