package com.tabletlauncher.data.model

/**
 * Sealed class representing an item that can occupy cells on the home screen grid.
 *
 * Can either be a standalone application [AppItem], an app folder [FolderItem],
 * or a built-in widget [WidgetItem].
 */
sealed class HomeScreenItem {
    abstract val id: String

    /**
     * A standalone application item on the home screen (1x1).
     */
    data class AppItem(val app: AppInfo) : HomeScreenItem() {
        override val id: String get() = app.packageName
    }

    /**
     * An iPadOS-style app folder item containing multiple applications (1x1).
     */
    data class FolderItem(val folder: AppFolder) : HomeScreenItem() {
        override val id: String get() = folder.id
    }

    /**
     * An iPadOS-style built-in widget occupying multiple grid cells (e.g. 2x2, 4x2, 4x4).
     */
    data class WidgetItem(val widget: WidgetInfo) : HomeScreenItem() {
        override val id: String get() = widget.id
    }
}
