package com.tabletlauncher.ui.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.ui.theme.InterFontFamily

/**
 * Mock forecast day item.
 */
private data class DayForecast(
    val day: String,
    val iconEmoji: String,
    val high: String,
    val low: String
)

private val MockFiveDayForecast = listOf(
    DayForecast("Thu", "☀️", "74°", "56°"),
    DayForecast("Fri", "⛅", "71°", "54°"),
    DayForecast("Sat", "🌧️", "65°", "50°"),
    DayForecast("Sun", "🌤️", "68°", "52°"),
    DayForecast("Mon", "☀️", "73°", "55°")
)

/**
 * iPadOS-style Weather Widget (Medium 4x2):
 * 1. Left side:
 *    - City title "Local Weather" above temperature.
 *    - Large "72°" temperature reading with a vibrant golden sun icon.
 *    - Condition text "Sunny" below with High/Low bounds.
 * 2. Right side:
 *    - 5-day forecast row with day abbreviations, weather icons, and high/low temperatures.
 */
@Composable
fun WeatherWidget(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0x351B4F72),
                        Color(0x20154360)
                    )
                )
            )
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // LEFT SIDE: Current Weather Info
            Column(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.Start
            ) {
                // City / Location Header
                Text(
                    text = "Local Weather",
                    fontFamily = InterFontFamily,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White.copy(alpha = 0.85f)
                )

                // Current Temperature & Sun Icon
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = "72°",
                        fontFamily = InterFontFamily,
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Rounded.WbSunny,
                        contentDescription = "Sunny",
                        tint = Color(0xFFFFD60A),
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Condition & High/Low
                Column {
                    Text(
                        text = "Sunny",
                        fontFamily = InterFontFamily,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = "H:74°  L:56°",
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White.copy(alpha = 0.70f)
                    )
                }
            }

            // Subtle vertical separator
            Box(
                modifier = Modifier
                    .fillMaxHeight(0.85f)
                    .width(1.dp)
                    .background(Color.White.copy(alpha = 0.15f))
            )

            Spacer(modifier = Modifier.width(12.dp))

            // RIGHT SIDE: 5-Day Forecast Row
            Row(
                modifier = Modifier
                    .weight(1.35f)
                    .fillMaxHeight(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MockFiveDayForecast.forEach { item ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxHeight(0.88f)
                    ) {
                        // Day Abbreviation
                        Text(
                            text = item.day,
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.80f)
                        )

                        // Condition Emoji
                        Text(
                            text = item.iconEmoji,
                            fontSize = 18.sp
                        )

                        // High Temp
                        Text(
                            text = item.high,
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )

                        // Low Temp
                        Text(
                            text = item.low,
                            fontFamily = InterFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.White.copy(alpha = 0.55f)
                        )
                    }
                }
            }
        }
    }
}
