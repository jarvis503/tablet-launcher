package com.tabletlauncher.ui.widgets

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tabletlauncher.data.model.WidgetInfo
import com.tabletlauncher.data.model.WidgetType
import com.tabletlauncher.ui.animation.jiggle
import com.tabletlauncher.ui.theme.FrostedGlassBackground
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.IosShadowBlue

// iPadOS-style widget shape: 16dp corner radius
val WidgetCardShape = RoundedCornerShape(16.dp)

/**
 * Base composable framework for iPadOS-style home screen widgets.
 *
 * Characteristics:
 * 1. Frosted glass rounded rectangle background (cornerRadius 20dp, white 15% opacity).
 * 2. Subtle white translucent border (1dp, white 20% opacity).
 * 3. Soft drop shadow (12dp elevation).
 * 4. Interactive touch feedback: scales to 0.96 with spring physics on press.
 * 5. Tap and Long-press support (activates Jiggle Mode).
 * 6. Jiggle animation: subtle -2° to +2° continuous rotation.
 * 7. Top-left minus delete badge in Jiggle Mode to remove widget from home screen.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherWidget(
    widget: WidgetInfo,
    onClick: () -> Unit = {},
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    isJiggleMode: Boolean = false,
    seed: Int = 0,
    onDeleteClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val context = LocalContext.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Smooth spring scale animation on press
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "launcher_widget_press_scale"
    )

    Box(
        modifier = modifier.jiggle(isJiggleMode = isJiggleMode, seed = seed),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .shadow(
                    elevation = 12.dp,
                    shape = WidgetCardShape,
                    clip = false,
                    ambientColor = IosShadowBlue.copy(alpha = 0.35f),
                    spotColor = IosShadowBlue.copy(alpha = 0.50f)
                )
                .clip(WidgetCardShape)
                .background(FrostedGlassBackground)
                .border(
                    BorderStroke(0.5.dp, FrostedGlassBorder),
                    WidgetCardShape
                )
                .drawWithContent {
                    drawContent()
                    // Subtle inner shadow / top-to-bottom glass sheen
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.07f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.08f)
                            )
                        )
                    )
                }
                .combinedClickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick,
                    onLongClick = {
                        if (onLongClick != null) {
                            onLongClick()
                        } else {
                            Toast.makeText(
                                context,
                                "${widget.title} Widget (${widget.size.name})",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            content()
        }

        // Top-Left Minus/Delete Badge in Jiggle Mode (22dp gray circle with white minus)
        if (isJiggleMode && onDeleteClick != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (-4).dp, y = (-4).dp)
                    .size(22.dp)
                    .shadow(4.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color(0xFF48484A))
                    .border(
                        BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
                        CircleShape
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onDeleteClick()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Remove,
                    contentDescription = "Remove Widget",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

/**
 * Renders the built-in widget content corresponding to [widget.type].
 */
@Composable
fun WidgetContent(
    widget: WidgetInfo,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when (widget.type) {
            WidgetType.Clock -> ClockWidget()
            WidgetType.Weather -> WeatherWidget()
            WidgetType.Calendar -> CalendarWidget()
            WidgetType.Battery -> BatteryWidget()
        }
    }
}
