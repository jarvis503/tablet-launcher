package com.tabletlauncher.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.SignalCellular4Bar
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.ui.theme.InterFontFamily
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Subtle text shadow to ensure crisp readability of white text and icons over wallpapers.
 */
private val StatusTextShadow = Shadow(
    color = Color.Black.copy(alpha = 0.5f),
    offset = Offset(0f, 1.5f),
    blurRadius = 3.5f
)

/**
 * Text style for the 14sp center time.
 */
private val StatusTimeTextStyle = TextStyle(
    fontFamily = InterFontFamily,
    fontSize = 14.sp,
    fontWeight = FontWeight.Medium, // Weight 500 (Medium)
    color = Color.White,
    shadow = StatusTextShadow
)

/**
 * Text style for 12sp labels (date, battery percentage).
 */
private val StatusLabelTextStyle = TextStyle(
    fontFamily = InterFontFamily,
    fontSize = 12.sp,
    fontWeight = FontWeight.Medium,
    color = Color.White,
    shadow = StatusTextShadow
)

/**
 * iPadOS-style status bar that overlays the wallpaper.
 *
 * Features:
 * - Translucent row overlaying the wallpaper
 * - Edge-to-edge drawing under system status bar area via [WindowInsets.statusBars]
 * - Current time centered in "h:mm" format (12-hour), updated every minute
 * - Current date on the left in "EEE, MMM d" format
 * - Mock status icons on the right: Wi-Fi, cellular signal, battery percentage + battery icon
 * - Height: 44dp
 * - Typography: 14sp for time, 12sp for date and battery, with white color & subtle shadow
 */
@Composable
fun IpadStatusBar(
    modifier: Modifier = Modifier,
    batteryPercentage: Int = 100,
    onSwipeDownTopLeft: (() -> Unit)? = null,
    onSwipeDownTopRight: (() -> Unit)? = null
) {
    var currentTime by remember { mutableStateOf(getFormattedTime()) }
    var currentDate by remember { mutableStateOf(getFormattedDate()) }

    // Coroutine updating time and date every minute aligned with clock tick
    LaunchedEffect(Unit) {
        while (true) {
            currentTime = getFormattedTime()
            currentDate = getFormattedDate()
            val calendar = Calendar.getInstance()
            val seconds = calendar.get(Calendar.SECOND)
            val millis = calendar.get(Calendar.MILLISECOND)
            val delayMillis = ((60 - seconds) * 1000L - millis).coerceAtLeast(1000L)
            delay(delayMillis)
        }
    }

    // Outer container: translucent background drawing edge-to-edge under the system status bar
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.15f))
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        // Inner 44dp content row
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .padding(horizontal = 24.dp)
        ) {
            // LEFT 40%: Swipe Down & Tap Trigger for Notification Center
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.40f)
                    .fillMaxHeight()
                    .align(Alignment.CenterStart)
                    .pointerInput(onSwipeDownTopLeft) {
                        if (onSwipeDownTopLeft != null) {
                            detectVerticalDragGestures { _, dragAmount ->
                                if (dragAmount > 10f) {
                                    onSwipeDownTopLeft()
                                }
                            }
                        }
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onSwipeDownTopLeft?.invoke()
                    },
                contentAlignment = Alignment.CenterStart
            ) {
                // LEFT: Date (e.g. "Thu, Nov 7")
                Text(
                    text = currentDate,
                    style = StatusLabelTextStyle
                )
            }

            // CENTER: Current Time in 12-hour "h:mm" format with 200ms smooth crossfade on minute tick
            Crossfade(
                targetState = currentTime,
                animationSpec = tween(durationMillis = 200),
                modifier = Modifier.align(Alignment.Center),
                label = "status_bar_clock_crossfade"
            ) { time ->
                Text(
                    text = time,
                    style = StatusTimeTextStyle
                )
            }

            // RIGHT 40%: Swipe Down & Tap Trigger for Control Center
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.40f)
                    .fillMaxHeight()
                    .align(Alignment.CenterEnd)
                    .pointerInput(onSwipeDownTopRight) {
                        if (onSwipeDownTopRight != null) {
                            detectVerticalDragGestures { _, dragAmount ->
                                if (dragAmount > 10f) {
                                    onSwipeDownTopRight()
                                }
                            }
                        }
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onSwipeDownTopRight?.invoke()
                    },
                contentAlignment = Alignment.CenterEnd
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Wi-Fi Icon
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = "Wi-Fi Connected",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )

                    // Cellular Signal Icon
                    Icon(
                        imageVector = Icons.Default.SignalCellular4Bar,
                        contentDescription = "Cellular Signal",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )

                    // Battery percentage text
                    Text(
                        text = "$batteryPercentage%",
                        style = StatusLabelTextStyle,
                        modifier = Modifier.padding(start = 2.dp)
                    )

                    // Battery Icon
                    Icon(
                        imageVector = Icons.Default.BatteryFull,
                        contentDescription = "Battery Full",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

private fun getFormattedTime(): String {
    val formatter = SimpleDateFormat("h:mm", Locale.getDefault())
    return formatter.format(Date())
}

private fun getFormattedDate(): String {
    val formatter = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
    return formatter.format(Date())
}
