package com.tabletlauncher.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tabletlauncher.data.model.AppCategorizer
import com.tabletlauncher.data.model.AppFolder
import com.tabletlauncher.data.model.AppInfo
import com.tabletlauncher.data.model.HomeScreenItem
import com.tabletlauncher.data.model.WidgetInfo
import com.tabletlauncher.data.model.WidgetSize
import com.tabletlauncher.data.model.WidgetType
import com.tabletlauncher.data.repository.AppRepository
import com.tabletlauncher.data.repository.LauncherPreferences
import com.tabletlauncher.data.repository.SavedPageItem
import com.tabletlauncher.data.repository.SavedSettings
import com.tabletlauncher.ui.layout.DeviceOrientation
import com.tabletlauncher.ui.layout.LauncherDimens
import com.tabletlauncher.util.HapticUtil
import com.tabletlauncher.wallpaper.WallpaperManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Main ViewModel for TabletLauncher managing installed apps, home screen pages, dock state,
 * app folders, widgets, persistent state, and iPadOS-style Jiggle Mode (edit mode).
 */
class LauncherViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val appRepository = AppRepository(application.applicationContext)
    private val launcherPrefs = LauncherPreferences(application.applicationContext)

    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val allApps: StateFlow<List<AppInfo>> = _allApps.asStateFlow()

    private val _dockApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val dockApps: StateFlow<List<AppInfo>> = _dockApps.asStateFlow()

    // Home screen pages containing HomeScreenItem (AppItem, FolderItem, or WidgetItem)
    private val _homeScreenPages = MutableStateFlow<Map<Int, List<HomeScreenItem>>>(emptyMap())
    val homeScreenPages: StateFlow<Map<Int, List<HomeScreenItem>>> = _homeScreenPages.asStateFlow()

    // Currently opened folder state for FolderOpenView
    private val _openedFolder = MutableStateFlow<AppFolder?>(null)
    val openedFolder: StateFlow<AppFolder?> = _openedFolder.asStateFlow()

    // Jiggle Mode (Edit Mode) states
    private val _isJiggleMode = MutableStateFlow(false)
    val isJiggleMode: StateFlow<Boolean> = _isJiggleMode.asStateFlow()

    private val _isWidgetGalleryOpen = MutableStateFlow(false)
    val isWidgetGalleryOpen: StateFlow<Boolean> = _isWidgetGalleryOpen.asStateFlow()

    private val _appPendingRemoval = MutableStateFlow<AppInfo?>(null)
    val appPendingRemoval: StateFlow<AppInfo?> = _appPendingRemoval.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isNotificationCenterOpen = MutableStateFlow(false)
    val isNotificationCenterOpen: StateFlow<Boolean> = _isNotificationCenterOpen.asStateFlow()

    // Spotlight Search State
    private val _isSpotlightOpen = MutableStateFlow(false)
    val isSpotlightOpen: StateFlow<Boolean> = _isSpotlightOpen.asStateFlow()

    // Control Center States
    private val _isControlCenterOpen = MutableStateFlow(false)
    val isControlCenterOpen: StateFlow<Boolean> = _isControlCenterOpen.asStateFlow()

    private val _isAirplaneMode = MutableStateFlow(false)
    val isAirplaneMode: StateFlow<Boolean> = _isAirplaneMode.asStateFlow()

    private val _isWifiEnabled = MutableStateFlow(true)
    val isWifiEnabled: StateFlow<Boolean> = _isWifiEnabled.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(true)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _isAirDropEnabled = MutableStateFlow(true)
    val isAirDropEnabled: StateFlow<Boolean> = _isAirDropEnabled.asStateFlow()

    private val _isRotationLocked = MutableStateFlow(false)
    val isRotationLocked: StateFlow<Boolean> = _isRotationLocked.asStateFlow()

    private val _isDoNotDisturb = MutableStateFlow(false)
    val isDoNotDisturb: StateFlow<Boolean> = _isDoNotDisturb.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _isScreenMirroring = MutableStateFlow(false)
    val isScreenMirroring: StateFlow<Boolean> = _isScreenMirroring.asStateFlow()

    private val _brightness = MutableStateFlow(0.80f)
    val brightness: StateFlow<Float> = _brightness.asStateFlow()

    private val _volume = MutableStateFlow(0.65f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    init {
        restoreSettings()
        loadApps()
    }

    private fun restoreSettings() {
        val saved = launcherPrefs.getSettings()
        _isDarkMode.value = saved.isDarkMode
        _isAirplaneMode.value = saved.isAirplaneMode
        _isWifiEnabled.value = saved.isWifiEnabled
        _isBluetoothEnabled.value = saved.isBluetoothEnabled
        _isAirDropEnabled.value = saved.isAirDropEnabled
        _isRotationLocked.value = saved.isRotationLocked
        _isDoNotDisturb.value = saved.isDoNotDisturb
        _brightness.value = saved.brightness
        _volume.value = saved.volume
        WallpaperManager.setDarkMode(saved.isDarkMode)
    }

    private fun persistSettings() {
        viewModelScope.launch(Dispatchers.IO) {
            launcherPrefs.saveSettings(
                SavedSettings(
                    isDarkMode = _isDarkMode.value,
                    isAirplaneMode = _isAirplaneMode.value,
                    isWifiEnabled = _isWifiEnabled.value,
                    isBluetoothEnabled = _isBluetoothEnabled.value,
                    isAirDropEnabled = _isAirDropEnabled.value,
                    isRotationLocked = _isRotationLocked.value,
                    isDoNotDisturb = _isDoNotDisturb.value,
                    brightness = _brightness.value,
                    volume = _volume.value
                )
            )
        }
    }

    private fun persistLayout() {
        viewModelScope.launch(Dispatchers.IO) {
            launcherPrefs.saveHomeScreenPages(_homeScreenPages.value)
        }
    }

    private fun persistDock() {
        viewModelScope.launch(Dispatchers.IO) {
            launcherPrefs.saveDockApps(_dockApps.value.map { it.packageName })
        }
    }

    /**
     * Activates Jiggle Mode (home screen edit mode) with 50ms haptic feedback.
     */
    fun enterJiggleMode(context: Context) {
        _isJiggleMode.value = true
        HapticUtil.vibrate(context, 50L)
    }

    /**
     * Exits Jiggle Mode, stopping all jiggle animations and closing edit overlays.
     */
    fun exitJiggleMode() {
        _isJiggleMode.value = false
        _isWidgetGalleryOpen.value = false
        _appPendingRemoval.value = null
    }

    fun openWidgetGallery() {
        _isWidgetGalleryOpen.value = true
    }

    fun closeWidgetGallery() {
        _isWidgetGalleryOpen.value = false
    }

    fun requestRemoveApp(app: AppInfo) {
        _appPendingRemoval.value = app
    }

    fun cancelRemoveApp() {
        _appPendingRemoval.value = null
    }

    /**
     * Removes an app from the home screen pages.
     * Note: Does not uninstall the app; remains available in the App Library.
     */
    fun confirmRemoveApp(app: AppInfo) {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        for ((_, items) in currentPages) {
            items.removeAll { it is HomeScreenItem.AppItem && it.app.packageName == app.packageName }
        }
        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        _appPendingRemoval.value = null
        persistLayout()
    }

    /**
     * Instantiates and adds a new widget to the specified page.
     */
    fun addWidgetToPage(pageIndex: Int, widgetType: WidgetType) {
        val newWidget = WidgetInfo(
            type = widgetType,
            title = widgetType.name
        )
        addWidget(pageIndex, newWidget)
    }

    /**
     * Reorders an item within a single home screen page.
     */
    fun reorderPageItems(pageIndex: Int, fromIndex: Int, toIndex: Int) {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        val pageItems = currentPages[pageIndex] ?: return
        if (fromIndex !in pageItems.indices) return
        val item = pageItems.removeAt(fromIndex)
        val clampedTo = toIndex.coerceIn(0, pageItems.size)
        pageItems.add(clampedTo, item)
        currentPages[pageIndex] = pageItems
        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        persistLayout()
    }

    /**
     * Creates a folder by dropping one app over another.
     */
    fun createFolderFromDrop(sourceApp: AppInfo, targetApp: AppInfo) {
        createFolder(targetApp, sourceApp, "Folder")
    }

    /**
     * Moves an item from one page to another (e.g. dragging across page edges).
     */
    fun moveItemToPage(fromPage: Int, itemId: String, toPage: Int) {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        val sourceItems = currentPages[fromPage] ?: return
        val itemIndex = sourceItems.indexOfFirst { it.id == itemId }
        if (itemIndex == -1) return
        val item = sourceItems.removeAt(itemIndex)
        val destItems = currentPages.getOrPut(toPage) { mutableListOf() }
        destItems.add(item)
        currentPages[fromPage] = sourceItems
        currentPages[toPage] = destItems
        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        persistLayout()
    }

    /**
     * Reorders dock apps in Jiggle Mode.
     */
    fun reorderDockApps(fromIndex: Int, toIndex: Int) {
        val list = _dockApps.value.toMutableList()
        if (fromIndex !in list.indices) return
        val item = list.removeAt(fromIndex)
        val clampedTo = toIndex.coerceIn(0, list.size)
        list.add(clampedTo, item)
        _dockApps.value = list
        persistDock()
    }

    fun openNotificationCenter() {
        _isNotificationCenterOpen.value = true
    }

    fun closeNotificationCenter() {
        _isNotificationCenterOpen.value = false
    }

    fun openSpotlight() {
        _isSpotlightOpen.value = true
    }

    fun closeSpotlight() {
        _isSpotlightOpen.value = false
    }

    fun openControlCenter() {
        _isControlCenterOpen.value = true
    }

    fun closeControlCenter() {
        _isControlCenterOpen.value = false
    }

    fun toggleAirplaneMode() {
        _isAirplaneMode.value = !_isAirplaneMode.value
        persistSettings()
    }

    fun toggleWifi() {
        _isWifiEnabled.value = !_isWifiEnabled.value
        persistSettings()
    }

    fun toggleBluetooth() {
        _isBluetoothEnabled.value = !_isBluetoothEnabled.value
        persistSettings()
    }

    fun toggleAirDrop() {
        _isAirDropEnabled.value = !_isAirDropEnabled.value
        persistSettings()
    }

    fun toggleRotationLock() {
        _isRotationLocked.value = !_isRotationLocked.value
        persistSettings()
    }

    fun toggleDoNotDisturb() {
        _isDoNotDisturb.value = !_isDoNotDisturb.value
        persistSettings()
    }

    fun toggleDarkMode() {
        val newDark = !_isDarkMode.value
        _isDarkMode.value = newDark
        WallpaperManager.setDarkMode(newDark)
        persistSettings()
    }

    fun toggleScreenMirroring() {
        _isScreenMirroring.value = !_isScreenMirroring.value
    }

    fun setBrightness(value: Float) {
        _brightness.value = value.coerceIn(0f, 1f)
        persistSettings()
    }

    fun setVolume(value: Float) {
        _volume.value = value.coerceIn(0f, 1f)
        persistSettings()
    }

    /**
     * Opens the specified folder overlay.
     */
    fun openFolder(folder: AppFolder) {
        if (!_isJiggleMode.value) {
            _openedFolder.value = folder
        }
    }

    /**
     * Closes the active folder overlay.
     */
    fun closeFolder() {
        _openedFolder.value = null
    }

    /**
     * Loads installed launchable apps and restores persisted home screen pages and dock,
     * or auto-generates them if launching for the first time.
     */
    fun loadApps(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val apps = appRepository.getInstalledApps(forceRefresh = forceRefresh)
                _allApps.value = apps

                val appMap = apps.associateBy { it.packageName }

                // 1. Restore or populate Dock
                val savedDockPkgs = launcherPrefs.getDockApps()
                if (savedDockPkgs != null && savedDockPkgs.isNotEmpty()) {
                    val restoredDock = savedDockPkgs.mapNotNull { appMap[it] }
                    if (restoredDock.isNotEmpty()) {
                        _dockApps.value = restoredDock
                    } else if (apps.isNotEmpty()) {
                        val defaultDock = selectDefaultDockApps(apps)
                        _dockApps.value = defaultDock
                        persistDock()
                    }
                } else if (apps.isNotEmpty()) {
                    val defaultDock = selectDefaultDockApps(apps)
                    _dockApps.value = defaultDock
                    persistDock()
                }

                // 2. Restore or populate Home Screen Pages
                val savedLayout = launcherPrefs.getHomeScreenPages()
                if (savedLayout != null && savedLayout.isNotEmpty()) {
                    val restoredPages = mutableMapOf<Int, List<HomeScreenItem>>()
                    val placedPackages = mutableSetOf<String>()

                    for ((pageIdx, savedItems) in savedLayout) {
                        val pageItems = mutableListOf<HomeScreenItem>()
                        for (item in savedItems) {
                            when (item) {
                                is SavedPageItem.App -> {
                                    val app = appMap[item.packageName]
                                    if (app != null) {
                                        pageItems.add(HomeScreenItem.AppItem(app))
                                        placedPackages.add(app.packageName)
                                    }
                                }
                                is SavedPageItem.Folder -> {
                                    val folderApps = item.packageNames.mapNotNull { appMap[it] }.toMutableList()
                                    if (folderApps.isNotEmpty()) {
                                        val folder = AppFolder(
                                            id = item.id,
                                            name = item.name,
                                            apps = folderApps
                                        )
                                        pageItems.add(HomeScreenItem.FolderItem(folder))
                                        folderApps.forEach { placedPackages.add(it.packageName) }
                                    }
                                }
                                is SavedPageItem.Widget -> {
                                    val type = try {
                                        WidgetType.valueOf(item.widgetType)
                                    } catch (e: Exception) {
                                        WidgetType.Weather
                                    }
                                    val size = try {
                                        WidgetSize.valueOf(item.size)
                                    } catch (e: Exception) {
                                        type.defaultSize
                                    }
                                    val widget = WidgetInfo(
                                        id = item.id,
                                        type = type,
                                        size = size,
                                        title = item.title
                                    )
                                    pageItems.add(HomeScreenItem.WidgetItem(widget))
                                }
                            }
                        }
                        if (pageItems.isNotEmpty()) {
                            restoredPages[pageIdx] = pageItems
                        }
                    }

                    // Append any newly installed apps that are not in dock or on any page
                    val dockPackages = _dockApps.value.map { it.packageName }.toSet()
                    val unplacedApps = apps.filter { it.packageName !in placedPackages && it.packageName !in dockPackages }

                    if (unplacedApps.isNotEmpty()) {
                        val lastPageIdx = (restoredPages.keys.maxOrNull() ?: 0) + 1
                        restoredPages[lastPageIdx] = unplacedApps.map { HomeScreenItem.AppItem(it) }
                    }

                    if (restoredPages.isNotEmpty()) {
                        _homeScreenPages.value = restoredPages
                    } else {
                        distributeAppsAcrossPages(apps)
                        persistLayout()
                    }
                } else {
                    distributeAppsAcrossPages(apps)
                    persistLayout()
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Finds common apps on the device to pre-populate the iPadOS dock:
     * - Browser, Phone, Messaging, Camera, Email, Settings, File Manager
     */
    private fun selectDefaultDockApps(allInstalledApps: List<AppInfo>): List<AppInfo> {
        val commonCategories = listOf(
            // 1. Browser
            listOf("com.android.chrome", "org.mozilla.firefox", "com.brave.browser", "com.microsoft.emmx", "com.opera.browser", "com.android.browser", "browser", "safari"),
            // 2. Phone / Dialer
            listOf("com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer", "com.android.phone", "dialer", "phone"),
            // 3. Messaging
            listOf("com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging", "com.whatsapp", "messaging", "messages"),
            // 4. Camera
            listOf("com.google.android.GoogleCamera", "com.android.camera", "com.android.camera2", "com.sec.android.app.camera", "camera"),
            // 5. Email
            listOf("com.google.android.gm", "com.android.email", "com.microsoft.office.outlook", "email", "gmail", "mail"),
            // 6. Settings
            listOf("com.android.settings", "com.google.android.settings", "settings", "preferences"),
            // 7. File Manager
            listOf("com.google.android.apps.nbu.files", "com.android.documentsui", "com.sec.android.app.myfiles", "com.android.filemanager", "files", "filemanager")
        )

        val selected = mutableListOf<AppInfo>()
        val remaining = allInstalledApps.toMutableList()

        for (patterns in commonCategories) {
            val match = remaining.firstOrNull { app ->
                patterns.any { pattern ->
                    app.packageName.equals(pattern, ignoreCase = true) ||
                    app.packageName.contains(pattern, ignoreCase = true) ||
                    app.label.equals(pattern, ignoreCase = true)
                }
            }
            if (match != null) {
                selected.add(match)
                remaining.remove(match)
            }
        }

        if (selected.size < 6 && remaining.isNotEmpty()) {
            val fillCount = (6 - selected.size).coerceAtMost(remaining.size)
            selected.addAll(remaining.take(fillCount))
        }

        return selected
    }

    /**
     * Distributes apps across home screen pages:
     * 1. Auto-groups apps into folders ("Google", "Social", "Utilities").
     * 2. Places the Weather widget on Page 1 (top area) by default.
     * 3. Places the Calendar widget on Page 2 (top area) by default.
     * 4. Fills remaining space with app and folder items.
     */
    fun distributeAppsAcrossPages(
        apps: List<AppInfo> = _allApps.value,
        pageSize: Int = LauncherDimens.getAppsPerPage(DeviceOrientation.Landscape) // 28
    ) {
        val items = mutableListOf<HomeScreenItem>()
        val remainingApps = apps.toMutableList()

        // 1. Auto-group "Google" folder (apps with google in pkg/label or core Google apps)
        val googleMatches = remainingApps.filter { app ->
            val pkg = app.packageName.lowercase()
            val lbl = app.label.lowercase()
            pkg.contains("google") ||
            pkg.startsWith("com.google.") ||
            pkg == "com.android.chrome" ||
            lbl.contains("google") ||
            lbl in listOf("gmail", "chrome", "maps", "drive", "photos", "youtube", "keep", "docs", "sheets", "slides")
        }

        if (googleMatches.size >= 2) {
            val googleFolder = AppFolder(
                name = "Google",
                apps = googleMatches.toMutableList()
            )
            items.add(HomeScreenItem.FolderItem(googleFolder))
            remainingApps.removeAll(googleMatches)
        }

        // 2. Auto-group "Social" folder
        val socialMatches = remainingApps.filter { app ->
            val cat = AppCategorizer.categorize(app, getApplication())
            val pkg = app.packageName.lowercase()
            val lbl = app.label.lowercase()
            cat == "Social" ||
            pkg.contains("facebook") || pkg.contains("instagram") || pkg.contains("twitter") ||
            pkg.contains("snapchat") || pkg.contains("whatsapp") || pkg.contains("telegram") ||
            pkg.contains("discord") || pkg.contains("reddit") || pkg.contains("linkedin") ||
            pkg.contains("tiktok") || lbl.contains("message") || lbl.contains("chat")
        }

        if (socialMatches.size >= 2) {
            val socialFolder = AppFolder(
                name = "Social",
                apps = socialMatches.toMutableList()
            )
            items.add(HomeScreenItem.FolderItem(socialFolder))
            remainingApps.removeAll(socialMatches)
        }

        // 3. Fallback Auto-group: "Utilities" folder if no folders formed yet
        if (items.isEmpty()) {
            val utilityMatches = remainingApps.filter { app ->
                val cat = AppCategorizer.categorize(app, getApplication())
                val pkg = app.packageName.lowercase()
                val lbl = app.label.lowercase()
                cat == "Utilities" || cat == "Productivity" ||
                lbl in listOf("clock", "calculator", "calendar", "settings", "files", "notes", "tasks") ||
                pkg.contains("calculator") || pkg.contains("deskclock") || pkg.contains("calendar")
            }

            if (utilityMatches.size >= 2) {
                val utilityFolder = AppFolder(
                    name = "Utilities",
                    apps = utilityMatches.toMutableList()
                )
                items.add(HomeScreenItem.FolderItem(utilityFolder))
                remainingApps.removeAll(utilityMatches)
            }
        }

        // Add all remaining apps as standalone AppItem entries
        remainingApps.forEach { app ->
            items.add(HomeScreenItem.AppItem(app))
        }

        // Default built-in widgets
        val defaultWeatherWidget = HomeScreenItem.WidgetItem(
            WidgetInfo(
                id = "default_weather_widget",
                type = WidgetType.Weather,
                size = WidgetSize.Medium,
                title = "Weather"
            )
        )

        val defaultCalendarWidget = HomeScreenItem.WidgetItem(
            WidgetInfo(
                id = "default_calendar_widget",
                type = WidgetType.Calendar,
                size = WidgetSize.Medium,
                title = "Calendar"
            )
        )

        val widgetCellFootprint = defaultWeatherWidget.widget.size.cellCount // 8
        val pageWithWidgetAppCapacity = (pageSize - widgetCellFootprint).coerceAtLeast(1)

        val pages = mutableMapOf<Int, List<HomeScreenItem>>()

        // Page 1: Weather widget at top + first batch of apps/folders
        val page1Apps = items.take(pageWithWidgetAppCapacity)
        pages[0] = listOf(defaultWeatherWidget) + page1Apps

        // Page 2: Calendar widget at top + second batch of apps/folders
        val remainingAfterPage1 = items.drop(pageWithWidgetAppCapacity)
        val page2Apps = remainingAfterPage1.take(pageWithWidgetAppCapacity)
        pages[1] = listOf(defaultCalendarWidget) + page2Apps

        // Page 3 and beyond: Any remaining apps/folders chunked by standard pageSize
        val remainingAfterPage2 = remainingAfterPage1.drop(pageWithWidgetAppCapacity)
        if (remainingAfterPage2.isNotEmpty()) {
            remainingAfterPage2.chunked(pageSize).forEachIndexed { chunkIndex, chunkItems ->
                pages[2 + chunkIndex] = chunkItems
            }
        }

        _homeScreenPages.value = pages
    }

    /**
     * Adds a widget to a specific home screen page.
     */
    fun addWidget(pageIndex: Int, widget: WidgetInfo) {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        val pageList = currentPages.getOrPut(pageIndex) { mutableListOf() }
        pageList.add(HomeScreenItem.WidgetItem(widget))
        currentPages[pageIndex] = pageList
        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        persistLayout()
    }

    /**
     * Removes a widget by its ID across all home screen pages.
     */
    fun removeWidget(widgetId: String) {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        for ((_, items) in currentPages) {
            items.removeAll { it is HomeScreenItem.WidgetItem && it.widget.id == widgetId }
        }
        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        persistLayout()
    }

    /**
     * Creates a new folder containing [app1] and [app2], placing it on the home screen
     * in place of [app1].
     */
    fun createFolder(app1: AppInfo, app2: AppInfo, folderName: String = "Folder"): AppFolder {
        val folder = AppFolder(
            name = folderName,
            apps = mutableListOf(app1, app2)
        )
        val folderItem = HomeScreenItem.FolderItem(folder)

        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        var placed = false

        for ((_, items) in currentPages) {
            val idx = items.indexOfFirst { it is HomeScreenItem.AppItem && it.app.packageName == app1.packageName }
            if (idx != -1) {
                items[idx] = folderItem
                placed = true
                break
            }
        }

        for ((_, items) in currentPages) {
            items.removeAll { it is HomeScreenItem.AppItem && it.app.packageName == app2.packageName }
        }

        if (!placed) {
            val page0 = currentPages.getOrPut(0) { mutableListOf() }
            page0.add(folderItem)
        }

        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        persistLayout()
        return folder
    }

    /**
     * Adds an app to the folder with the given [folderId].
     */
    fun addToFolder(folderId: String, app: AppInfo): Boolean {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        var targetFolder: AppFolder? = null

        for ((_, items) in currentPages) {
            val item = items.firstOrNull { it is HomeScreenItem.FolderItem && it.folder.id == folderId } as? HomeScreenItem.FolderItem
            if (item != null) {
                targetFolder = item.folder
                if (targetFolder.apps.none { it.packageName == app.packageName }) {
                    targetFolder.apps.add(app)
                }
                break
            }
        }

        if (targetFolder == null) return false

        for ((_, items) in currentPages) {
            items.removeAll { it is HomeScreenItem.AppItem && it.app.packageName == app.packageName }
        }

        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }

        if (_openedFolder.value?.id == folderId) {
            _openedFolder.value = targetFolder.copy(apps = targetFolder.apps.toMutableList())
        }
        persistLayout()
        return true
    }

    /**
     * Removes an app from the folder, returning it as an [HomeScreenItem.AppItem] to the home screen.
     */
    fun removeFromFolder(folderId: String, app: AppInfo): Boolean {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        var targetFolder: AppFolder? = null
        var folderPageIdx = 0

        for ((pageIdx, items) in currentPages) {
            val item = items.firstOrNull { it is HomeScreenItem.FolderItem && it.folder.id == folderId } as? HomeScreenItem.FolderItem
            if (item != null) {
                targetFolder = item.folder
                folderPageIdx = pageIdx
                break
            }
        }

        if (targetFolder == null) return false

        targetFolder.apps.removeAll { it.packageName == app.packageName }
        currentPages[folderPageIdx]?.add(HomeScreenItem.AppItem(app))

        if (targetFolder.apps.isEmpty()) {
            for ((_, items) in currentPages) {
                items.removeAll { it is HomeScreenItem.FolderItem && it.folder.id == folderId }
            }
            if (_openedFolder.value?.id == folderId) {
                _openedFolder.value = null
            }
        } else {
            if (_openedFolder.value?.id == folderId) {
                _openedFolder.value = targetFolder.copy(apps = targetFolder.apps.toMutableList())
            }
        }

        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        persistLayout()
        return true
    }

    /**
     * Renames an existing folder.
     */
    fun renameFolder(folderId: String, newName: String): Boolean {
        val resolvedName = newName.trim().ifBlank { "Folder" }
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        var updated = false

        for ((_, items) in currentPages) {
            val item = items.firstOrNull { it is HomeScreenItem.FolderItem && it.folder.id == folderId } as? HomeScreenItem.FolderItem
            if (item != null) {
                item.folder.name = resolvedName
                if (_openedFolder.value?.id == folderId) {
                    _openedFolder.value = item.folder.copy(name = resolvedName, apps = item.folder.apps.toMutableList())
                }
                updated = true
                break
            }
        }

        if (updated) {
            _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
            persistLayout()
        }
        return updated
    }

    /**
     * Moves a home screen item from one position to another.
     */
    fun moveItem(fromPage: Int, fromIndex: Int, toPage: Int, toIndex: Int) {
        val currentPages = _homeScreenPages.value.mapValues { it.value.toMutableList() }.toMutableMap()
        val sourceList = currentPages[fromPage] ?: return

        if (fromIndex !in sourceList.indices) return
        val movedItem = sourceList.removeAt(fromIndex)

        if (fromPage == toPage) {
            val clampedToIndex = toIndex.coerceIn(0, sourceList.size)
            sourceList.add(clampedToIndex, movedItem)
            currentPages[fromPage] = sourceList
        } else {
            val destList = currentPages[toPage] ?: mutableListOf()
            val clampedToIndex = toIndex.coerceIn(0, destList.size)
            destList.add(clampedToIndex, movedItem)
            currentPages[fromPage] = sourceList
            currentPages[toPage] = destList
        }

        _homeScreenPages.value = currentPages.mapValues { it.value.toList() }
        persistLayout()
    }

    /**
     * Adds an app to the dock, enforcing portrait (max 8) and landscape (max 15) limits.
     */
    fun addToDock(
        app: AppInfo,
        orientation: DeviceOrientation = DeviceOrientation.Landscape
    ): Boolean {
        val maxDockSize = when (orientation) {
            DeviceOrientation.Portrait -> MAX_DOCK_PORTRAIT
            DeviceOrientation.Landscape -> MAX_DOCK_LANDSCAPE
        }

        val currentDock = _dockApps.value
        if (currentDock.size >= maxDockSize) return false
        if (currentDock.any { it.packageName == app.packageName }) return false

        _dockApps.value = currentDock + app
        persistDock()
        return true
    }

    /**
     * Removes an app from the dock.
     */
    fun removeFromDock(app: AppInfo) {
        _dockApps.value = _dockApps.value.filter { it.packageName != app.packageName }
        persistDock()
    }

    /**
     * Resolves the launch intent for [packageName] and starts the target activity.
     */
    fun launchApp(context: Context, packageName: String): Boolean {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val options = android.app.ActivityOptions.makeCustomAnimation(
                    context,
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
                )
                context.startActivity(intent, options.toBundle())
                true
            } else {
                Toast.makeText(context, "Cannot launch app: $packageName", Toast.LENGTH_SHORT).show()
                false
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to launch: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    companion object {
        const val MAX_DOCK_PORTRAIT = 8
        const val MAX_DOCK_LANDSCAPE = 15
    }
}
