package com.tabletlauncher.ui.components

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.tabletlauncher.ui.theme.FrostedGlassBackground
import com.tabletlauncher.ui.theme.FrostedGlassBorder
import com.tabletlauncher.ui.theme.IosShadowBlue

/**
 * Reusable iPadOS Frosted Glass Box:
 * - Background: Color.White.copy(alpha = 0.15f) for dark mode.
 * - Border: thin 0.5dp of Color.White.copy(alpha = 0.10f).
 * - Subtle inner shadow / glass gradient sheen from top to bottom.
 * - Colored dark-blue tinted elevation shadow.
 * - Android 12+ (API 31+) hardware RenderEffect blur safely caught on older platforms.
 */
@Composable
fun FrostedGlassBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    backgroundColor: Color = FrostedGlassBackground,
    borderColor: Color = FrostedGlassBorder,
    borderWidth: Dp = 0.5.dp,
    elevation: Dp = 0.dp,
    shadowColor: Color = IosShadowBlue,
    contentAlignment: Alignment = Alignment.TopStart,
    content: @Composable BoxScope.() -> Unit
) {
    val shadowMod = if (elevation > 0.dp) {
        Modifier.shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = shadowColor.copy(alpha = 0.35f),
            spotColor = shadowColor.copy(alpha = 0.50f)
        )
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .then(shadowMod)
            .graphicsLayer {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        renderEffect = RenderEffect
                            .createBlurEffect(30f, 30f, Shader.TileMode.CLAMP)
                            .asComposeRenderEffect()
                    } catch (_: Throwable) {
                        // Safe fallback on platforms without RenderEffect support
                    }
                }
            }
            .clip(shape)
            .background(backgroundColor)
            .border(BorderStroke(borderWidth, borderColor), shape)
            .drawWithContent {
                drawContent()
                // Subtle inner shadow / top-to-bottom depth sheen
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.07f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.08f)
                        ),
                        startY = 0f,
                        endY = size.height
                    )
                )
            },
        contentAlignment = contentAlignment,
        content = content
    )
}
