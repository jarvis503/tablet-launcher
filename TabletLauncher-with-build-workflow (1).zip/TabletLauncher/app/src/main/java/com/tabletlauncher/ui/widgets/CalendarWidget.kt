package com.tabletlauncher.ui.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabletlauncher.ui.theme.InterFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mock calendar event data.
 */
private data class CalendarEvent(
    val title: String,
    val time: String,
    val dotColor: Color
)

private val MockEvents = listOf(
    CalendarEvent("Design Team Sync", "10:00 AM - 11:00 AM", Color(0xFF0A84FF)),
    CalendarEvent("Product Strategy Review", "1:30 PM - 2:15 PM", Color(0xFF30D158)),
    CalendarEvent("Quarterly Roadmap", "4:00 PM - 4:45 PM", Color(0xFFBF5AF2))
)

/**
 * iPadOS-style Calendar Widget (Medium 4x2):
 * 1. Left side: Today's date prominently displayed (day of week, day number, and month name).
 * 2. Right side: 2-3 mock calendar events with colored dots, title, and time interval.
 * 3. Bottom label: "No more events today" in muted gray.
 */
@Composable
fun CalendarWidget(
    modifier: Modifier = Modifier
) {
    val currentDate = remember { Date() }
    val dayOfWeek = remember {
        SimpleDateFormat("EEEE", Locale.getDefault()).format(currentDate).uppercase()
    }
    val dayNumber = remember {
        SimpleDateFormat("d", Locale.getDefault()).format(currentDate)
    }
    val monthName = remember {
        SimpleDateFormat("MMMM", Locale.getDefault()).format(currentDate)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // LEFT SIDE: Prominent Today's Date
            Column(
                modifier = Modifier
                    .weight(0.75f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start
            ) {
                // Day of Week in Apple Red
                Text(
                    text = dayOfWeek,
                    fontFamily = InterFontFamily,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFF3B30),
                    letterSpacing = 0.5.sp
                )

                // Large Day Number
                Text(
                    text = dayNumber,
                    fontFamily = InterFontFamily,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                // Month Name
                Text(
                    text = monthName,
                    fontFamily = InterFontFamily,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }

            // Vertical divider line
            Box(
                modifier = Modifier
                    .fillMaxHeight(0.85f)
                    .width(1.dp)
                    .background(Color.White.copy(alpha = 0.15f))
            )

            Spacer(modifier = Modifier.width(14.dp))

            // RIGHT SIDE: Upcoming Events List
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.Start
            ) {
                // Event Items
                MockEvents.forEach { event ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Colored event indicator dot
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(event.dotColor, CircleShape)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = event.title,
                                fontFamily = InterFontFamily,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = event.time,
                                fontFamily = InterFontFamily,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Normal,
                                color = Color.White.copy(alpha = 0.70f),
                                maxLines = 1
                            )
                        }
                    }
                }

                // Gray "No more events today" notice at bottom
                Text(
                    text = "No more events today",
                    fontFamily = InterFontFamily,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color.White.copy(alpha = 0.45f)
                )
            }
        }
    }
}
