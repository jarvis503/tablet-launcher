# Building the APK

1. Create a new GitHub repository and upload everything in this folder (including the hidden .github folder).
2. Open the repo's **Actions** tab -> "Build APK" -> wait for the green check (about 5-8 minutes).
3. Open the finished run and download **TabletLauncher-debug-apk** under Artifacts. Unzip it to get app-debug.apk.
4. Copy app-debug.apk to your tablet, allow "Install unknown apps", and open it.

Or, on a computer with Android Studio / JDK 17 + Android SDK: run `./gradlew assembleDebug`.
The APK is written to app/build/outputs/apk/debug/app-debug.apk.
